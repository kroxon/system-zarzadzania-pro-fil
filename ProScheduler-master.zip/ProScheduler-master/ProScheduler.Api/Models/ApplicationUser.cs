﻿using Microsoft.AspNetCore.Identity;

namespace ProScheduler.Api.Models;

public class ApplicationUser : IdentityUser
{
    public required string Name { get; set; }
    public required string Surname { get; set; }
    public required int OccupationId { get; set; }

    public Employee? Employee { get; set; }
    public Occupation Occupation { get; set; } = null!;
    public ICollection<IdentityUserRole<string>> UserRoles { get; set; } = new List<IdentityUserRole<string>>();
}