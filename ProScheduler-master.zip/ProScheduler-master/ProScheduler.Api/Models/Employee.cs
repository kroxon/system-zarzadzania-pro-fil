﻿namespace ProScheduler.Api.Models;

public class Employee : Person
{
    public required string ApplicationUserId { get; set; }

    public ApplicationUser ApplicationUser { get; set; } = null!;
    public ICollection<WorkHours> WorkHours { get; set; } = new List<WorkHours>();
    public ICollection<Patient> AssignedPatients { get; set; } = new List<Patient>();
    public ICollection<EmployeeTask> AssignedTasks { get; set; } = new HashSet<EmployeeTask>();

    public override bool IsAvailable(DateTime start, DateTime end)
    {
        var isWithinWorkHour = WorkHours.Any(wh => wh.Start <= end && wh.End >= start);
        bool check = base.IsAvailable(start, end);
        return isWithinWorkHour && check;
    }
}
