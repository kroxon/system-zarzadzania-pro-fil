﻿namespace ProScheduler.Api.Models;

public class EmployeeTask
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public bool IsCompleted { get; set; }
    public required DateOnly DueDate { get; set; }

    public ISet<Employee> AssignedEmployees { get; set; } = new HashSet<Employee>();
}
