﻿namespace ProScheduler.Api.Models;

public class Event
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public required DateTime Start { get; set; }
    public required DateTime End { get; set; }
    public int? RoomId { get; set; }
    public string? Guest { get; set; }
    public required int StatusId { get; set; }
    public string? Info { get; set; }

    public Room? Room { get; set; }
    public ISet<Person> Persons { get; set; } = new HashSet<Person>();
    public EventStatus Status { get; set; } = null!;
}
