﻿namespace ProScheduler.Api.Models;

public abstract class Person
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public required string Surname { get; set; }
    public string? Info { get; set; }

    public ICollection<Event> Events { get; set; } = new List<Event>();

    public virtual bool IsAvailable(DateTime start, DateTime end)
    {
        var conflict = Events.Any(e => e.Start < end && e.End > start);
        return !conflict;
    }
}
