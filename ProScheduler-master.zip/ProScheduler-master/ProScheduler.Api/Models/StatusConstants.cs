﻿namespace ProScheduler.Api.Models;

public static class StatusConstants
{
    public const int Planned = 1;
    public const int InProgress = 2;
    public const int Completed = 3;
    public const int Absent = 4;
    public const int Cancelled = 5;
}
