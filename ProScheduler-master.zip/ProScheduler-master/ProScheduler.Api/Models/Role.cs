﻿namespace ProScheduler.Api.Models;

public enum Role
{
    Admin,
    FirstContact,
    Employee
}
