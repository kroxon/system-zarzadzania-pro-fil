﻿namespace ProScheduler.Api.Models;

public class Room
{
    public int Id { get; set; }
    public required string Name { get; set; }
    public required string HexColor { get; set; }

    public ICollection<Event> Events { get; set; } = new List<Event>();
}