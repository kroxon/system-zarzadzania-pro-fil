﻿namespace ProScheduler.Api.Models;

public class Patient : Person
{
    public required DateOnly BirthDate { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<Employee> AssignedEmployees { get; set; } = new List<Employee>();
}
