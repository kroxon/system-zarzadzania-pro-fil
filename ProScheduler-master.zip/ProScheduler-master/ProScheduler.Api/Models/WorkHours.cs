﻿namespace ProScheduler.Api.Models;

public class WorkHours
{
    public int Id { get; set; }
    public required DateTime Start { get; set; }
    public required DateTime End { get; set; }
    public required int EmployeeId { get; set; }

    public Employee? Employee { get; set; }
}
