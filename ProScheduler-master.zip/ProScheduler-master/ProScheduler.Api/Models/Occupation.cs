﻿namespace ProScheduler.Api.Models;

public class Occupation
{
    public int Id { get; set; }
    public required string Name { get; set; }

    public ICollection<ApplicationUser> Users { get; set; } = new List<ApplicationUser>();
}
