﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Event;
using ProScheduler.Api.Contracts.Statistic;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Services;

public class StatisticsService(ApplicationDbContext db, ILogger<StatisticsService> logger)
{
    public async Task<MainPanelStatisticDto> GetMainPanelStatisticsAsync()
    {
        var eventsThisMonth = await db.Events
            .Where(e => e.Start.Month == DateTime.UtcNow.Month && e.Start.Year == DateTime.UtcNow.Year && e.StatusId != StatusConstants.Cancelled && e.StatusId != StatusConstants.Absent)
            .ToListAsync();
        var thisMonthCount = eventsThisMonth.Count;

        var eventsThisWeek = eventsThisMonth
            .Where(e => e.Start >= DateTime.UtcNow.AddDays(-(int)DateTime.UtcNow.DayOfWeek) && e.Start < DateTime.UtcNow.AddDays(7 - (int)DateTime.UtcNow.DayOfWeek))
            .ToList();
        var thisWeekCount = eventsThisWeek.Count;

        var tomorrowCount = eventsThisWeek
            .Where(e => e.Start.Date == DateTime.UtcNow.AddDays(1).Date)
            .Count();

        var todayCount = eventsThisWeek
            .Where(e => e.Start.Date == DateTime.UtcNow.Date)
            .Count();

        var activePatients = await db.Patients.CountAsync(p => p.IsActive);

        return new MainPanelStatisticDto
        {
            Today = todayCount,
            Tomorrow = tomorrowCount,
            ThisWeek = thisWeekCount,
            ThisMonth = thisMonthCount,
            ActivePatients = activePatients
        };
    }

    public async Task<List<EmployeeStatisticDto>> GetEventStatisticsAsync(int year, int? month = null, int? employeeId = null)
    {
        var allEvents = await db.Events
            .Include(e => e.Persons)
            .Where(e => e.Start.Year == year && (month == null || e.Start.Month == month) && (employeeId == null || e.Persons.Any(p => p.Id == employeeId)))
            .ToListAsync();

        List<EmployeeStatisticDto> employeeStatisticDtos = new();
        List<int> employeeIds = new();

        if (employeeId is null)
        {
            employeeIds = await db.Employees.Select(e => e.Id).ToListAsync();
        }
        else
        {
            employeeIds.Add(employeeId.Value);
        }

        foreach (var id in employeeIds)
        {
            var eventsForEmployee = allEvents
                .Where(e => e.Persons.Any(p => p.Id == id))
                .ToList();

            var totalEvents = eventsForEmployee
            .Where(e => e.StatusId == StatusConstants.Planned || e.StatusId == StatusConstants.Completed || e.StatusId == StatusConstants.InProgress)
            .Count();

            var completedEvents = eventsForEmployee
                .Where(e => e.StatusId == StatusConstants.Completed)
                .Count();

            var cancelledEvents = eventsForEmployee
                .Where(e => e.StatusId == StatusConstants.Cancelled)
                .Count();

            var absentPatients = eventsForEmployee
                .Where(e => e.StatusId == StatusConstants.Absent)
                .Count();

            employeeStatisticDtos.Add(new EmployeeStatisticDto
            {
                EmployeeId = id,
                TotalEvents = totalEvents,
                CompletedEvents = completedEvents,
                CancelledEvents = cancelledEvents,
                AbsentPatients = absentPatients
            });
        }

        return employeeStatisticDtos;
    }
}
