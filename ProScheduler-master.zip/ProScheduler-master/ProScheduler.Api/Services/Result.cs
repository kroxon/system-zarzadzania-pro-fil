﻿using System.Diagnostics.CodeAnalysis;

namespace ProScheduler.Api.Services;

public record Result
{
    [MemberNotNullWhen(false, nameof(Error))]
    public bool IsSuccess { get; }
    public Error? Error { get; }

    protected Result(bool isSuccess, Error? error)
    {
        IsSuccess = isSuccess;
        Error = error;
    }

    public static Result Success()
    {
        return new(true, null);
    }

    public static Result Failure(Error error)
    {
        return new(false, error ?? throw new ArgumentNullException(nameof(error)));
    }

    public static implicit operator Result(Error error)
    {
        return Failure(error);
    }
}

public record Result<T>
{
    [MemberNotNullWhen(true, nameof(Value))]
    [MemberNotNullWhen(false, nameof(Error))]
    public bool IsSuccess { get; }
    public Error? Error { get; }
    public T? Value { get; }

    private Result(T value)
    {
        IsSuccess = true;
        Error = null;
        Value = value;
    }

    private Result(Error error)
    {
        IsSuccess = false;
        Error = error ?? throw new ArgumentNullException(nameof(error));
        Value = default;
    }

    public static implicit operator Result<T>(T value)
    {
        return new(value);
    }

    public static implicit operator Result<T>(Error error)
    {
        return new(error);
    }
}

public enum ErrorType { NotFound, Validation, Internal, Forbidden }

public record Error(string Id, ErrorType Type, string Description);

public static class Errors
{
    public static Error EmployeeNotFound(int employeeId)
    {
        return new("EmployeeNotFound", ErrorType.NotFound, $"Employee with ID {employeeId} not found.");
    }
    public static Error OccupationNotFound(int occupationId)
    {
        return new("OccupationNotFound", ErrorType.Validation, $"Occupation with ID {occupationId} not found.");
    }
    public static Error EmailAlreadyExists(string email)
    {
        return new("EmailAlreadyExists", ErrorType.Validation, $"Employee with email {email} already exists.");
    }
    public static Error PatientNotFound(int patientId)
    {
        return new("PatientNotFound", ErrorType.NotFound, $"Patient with ID {patientId} not found.");
    }
    public static Error WorkHoursNotFound(int workHoursId)
    {
        return new("WorkHoursNotFound", ErrorType.NotFound, $"WorkHours with ID {workHoursId} not found.");
    }
    public static Error RoomNotFound(int roomId)
    {
        return new("RoomNotFound", ErrorType.NotFound, $"Room with ID {roomId} not found.");
    }
    public static Error RoomIdEmpty()
    {
        return new("InvalidArguments", ErrorType.Validation, "RoomId must be provided.");
    }
    public static Error AddPersonsIdsAndRemovePersonsIdsEmpty()
    {
        return new("InvalidArguments", ErrorType.Validation, "At least one of AddPersonsIds or RemovePersonsIds must be provided.");
    }
    public static Error RoomNotAvailable(int roomId)
    {
        return new("RoomIsNotAvailable", ErrorType.Validation, $"Room with ID {roomId} is not available.");
    }
    public static Error EventNotFound(int eventId)
    {
        return new("EventNotFound", ErrorType.NotFound, $"Event with ID {eventId} not found.");
    }
    public static Error InvalidTimeRange()
    {
        return new("InvalidTimeRange", ErrorType.Validation, "End time must be after start time.");
    }
    public static Error TimeRangeOverlaps()
    {
        return new("TimeRangeOverlaps", ErrorType.Validation, "Time range overlaps with another entity.");
    }
    public static Error PersonNotFound(int personId)
    {
        return new("PersonNotFound", ErrorType.NotFound, $"Person with ID {personId} not found.");
    }
    public static Error PersonNotAvailable(int personId)
    {
        return new("PersonIsNotAvailable", ErrorType.Validation, $"Person with ID {personId} is not available.");
    }
    public static Error PersonNotAvailable()
    {
        return new("PersonIsNotAvailable", ErrorType.Validation, $"Person is not available.");
    }
    public static Error EmployeeDeletionUnauthorized(int employeeId)
    {
        return new("EmployeeDeletionUnauthorized", ErrorType.Forbidden, $"You are not authorized to delete employee with ID {employeeId}.");
    }
    public static Error EmployeeDeletionFailed(int employeeId, string reason)
    {
        return new("EmployeeDeletionFailed", ErrorType.Internal, $"Failed to delete employee with ID {employeeId}. Reason: {reason}");
    }
    public static Error EmployeeUpdateFailed(int employeeId, string reason)
    {
        return new("EmployeeUpdateFailed", ErrorType.Internal, $"Failed to update employee with ID {employeeId}. Reason: {reason}");
    }
    public static Error EmployeeUpdateUnauthorized(int employeeId)
    {
        return new("EmployeeUpdateUnauthorized", ErrorType.Forbidden, $"You are not authorized to update employee with ID {employeeId}.");
    }
    public static Error EmployeeTaskNotFound(int employeeTaskId)
    {
        return new("EmployeeTaskNotFound", ErrorType.NotFound, $"Employee Task with Id {employeeTaskId} not found.");
    }
    public static Error EmployeeTasksAccessUnauthorized(int employeeId)
    {
        return new("EmployeeTasksAccessUnauthorized", ErrorType.Forbidden, $"You are not authorized to access tasks for employee with ID {employeeId}.");
    }
    public static Error EmployeeTaskDeletionUnauthorized(int employeeTaskId)
    {
        return new("EmployeeTaskDeletionUnauthorized", ErrorType.Forbidden, $"You are not authorized to delete employee task with ID {employeeTaskId}.");
    }
    public static Error EmployeeTaskCreationUnauthorized()
    {
        return new("EmployeeTaskCreationUnauthorized", ErrorType.Forbidden, $"You are not authorized to create task.");
    }
    public static Error EmployeeTaskUpdateUnauthorized(int employeeTaskId)
    {
        return new("EmployeeTaskUpdateUnauthorized", ErrorType.Forbidden, $"You are not authorized to update employee task with ID {employeeTaskId}.");
    }
    public static Error EmployeeIdClaimMissing()
    {
        return new("EmployeeIdClaimMissing", ErrorType.Internal, "EmployeeId claim is missing in the token.");
    }
}
