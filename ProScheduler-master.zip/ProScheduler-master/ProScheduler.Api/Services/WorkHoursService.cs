﻿
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.WorkHours;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Services;

public class WorkHoursService(ApplicationDbContext db, ILogger<WorkHoursService> logger) : IWorkHoursService
{
    public async Task<IEnumerable<WorkHoursDto>> GetAllWorkHoursAsync()
    {
        return await
            db
            .WorkHours
            .Select(wh => wh.ToDto())
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<Result<WorkHoursDto>> GetWorkHoursByIdAsync(int workHoursId)
    {
        var workHours = await
            db
            .WorkHours
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == workHoursId);

        if (workHours is null)
        {
            var error = Errors.WorkHoursNotFound(workHoursId);
            logger.LogWarning("WorkHours Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return workHours.ToDto();
    }

    public async Task<Result<WorkHoursDto>> CreateWorkHoursAsync(CreateWorkHoursDto createWorkHoursDto)
    {
        var workHours = createWorkHoursDto.ToEntity();

        var employeeExists = await db.Employees.AnyAsync(e => e.Id == workHours.EmployeeId);
        if (!employeeExists)
        {
            var error = Errors.EmployeeNotFound(workHours.EmployeeId);
            logger.LogError("WorkHours creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var workHoursOverlap = await db.WorkHours.AnyAsync(wh =>
            wh.EmployeeId == workHours.EmployeeId &&
            ((workHours.Start > wh.Start && workHours.Start < wh.End) ||
             (workHours.End > wh.Start && workHours.End < wh.End) ||
             (workHours.Start == wh.Start && workHours.End == wh.End) ||
             (workHours.Start < wh.Start && workHours.End > wh.End))
        );
        if (workHoursOverlap)
        {
            var error = Errors.TimeRangeOverlaps();
            logger.LogError("WorkHours creation failed due to overlapping hours. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        db.WorkHours.Add(workHours);
        await db.SaveChangesAsync();
        return workHours.ToDto();
    }

    public async Task<Result> UpdateWorkHoursAsync(int workHoursId, UpdateWorkHoursDto updateWorkHoursDto)
    {
        var updatedWorkHours = updateWorkHoursDto.ToEntity(workHoursId);
        var workHours = await db.WorkHours.FirstOrDefaultAsync(e => e.Id == workHoursId);
        if (workHours is null)
        {
            var error = Errors.WorkHoursNotFound(workHoursId);
            logger.LogWarning("WorkHours update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        db.Entry(workHours).CurrentValues.SetValues(updatedWorkHours);
        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task DeleteWorkHoursAsync(int workHoursId)
    {
        if (await db.WorkHours.Where(e => e.Id == workHoursId).ExecuteDeleteAsync() == 0)
        {
            var error = Errors.WorkHoursNotFound(workHoursId);
            logger.LogWarning("WorkHours deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
        }
        else
        {
            logger.LogInformation("WorkHours with Id {WorkHoursId} deleted successfully.", workHoursId);
        }
    }
}
