﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Services;

public class AvailabilityService(ApplicationDbContext db, ILogger<AvailabilityService> logger)
{
    public async Task<Result<ISet<Person>>> GetAvailablePersonsAsync(
        IEnumerable<int> personsToCheckIds,
        DateTime start,
        DateTime end)
    {
        if (end <= start)
        {
            var error = Errors.InvalidTimeRange();
            logger.LogWarning("Person availability check failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var personsResult = await GetPersonsWithIncludesAsync(personsToCheckIds);
        if (!personsResult.IsSuccess)
        {
            var error = personsResult.Error;
            logger.LogWarning("Person availability check failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var persons = personsResult.Value;
        foreach (var person in persons)
        {
            if (!person.IsAvailable(start, end))
            {
                var error = Errors.PersonNotAvailable(person.Id);
                logger.LogInformation("Person availability check: Person with ID {PersonId} is not available. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    person.Id, error.Id, error.Type, error.Description);
                return error;
            }
        }

        return persons.ToHashSet();
    }

    private async Task<Result<IEnumerable<Person>>> GetPersonsWithIncludesAsync(IEnumerable<int> personIds)
    {
        var employees = await db.Employees
            .Include(e => e.WorkHours)
            .Include(e => e.Events)
            .Where(e => personIds.Contains(e.Id))
            .ToListAsync();

        var patients = await db.Patients
            .Include(e => e.Events)
            .Where(p => personIds.Contains(p.Id))
            .ToListAsync();

        var persons = employees.Cast<Person>().Concat(patients).ToList();

        if (personIds.Distinct().Count() != persons.Count)
        {
            var error = Errors.PersonNotFound(personIds.Except(persons.Select(p => p.Id)).First());
            logger.LogWarning("Person retrieval failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return persons;
    }

    public async Task<Result<bool>> IsRoomAvailableAsync(int roomId, DateTime startTime, DateTime endTime, int? eventToExcludeId = null)
    {
        if (!await db.Rooms.AnyAsync(r => r.Id == roomId))
        {
            var error = Errors.RoomNotFound(roomId);
            logger.LogWarning("Room availability check failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var result = await db.Events
            .Where(e => 
                e.RoomId == roomId 
                && e.Start < endTime 
                && e.End > startTime
                && !(e.Id == eventToExcludeId))
            .AnyAsync();
        return !result;
    }
}
