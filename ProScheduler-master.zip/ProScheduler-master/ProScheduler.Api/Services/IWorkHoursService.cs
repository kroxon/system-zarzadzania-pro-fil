﻿using ProScheduler.Api.Contracts.WorkHours;

namespace ProScheduler.Api.Services;

public interface IWorkHoursService
{
    Task<IEnumerable<WorkHoursDto>> GetAllWorkHoursAsync();
    Task<Result<WorkHoursDto>> GetWorkHoursByIdAsync(int workHoursId);
    Task<Result<WorkHoursDto>> CreateWorkHoursAsync(CreateWorkHoursDto createWorkHoursDto);
    Task<Result> UpdateWorkHoursAsync(int workHoursId, UpdateWorkHoursDto updateWorkHoursDto);
    Task DeleteWorkHoursAsync(int workHoursId);
}
