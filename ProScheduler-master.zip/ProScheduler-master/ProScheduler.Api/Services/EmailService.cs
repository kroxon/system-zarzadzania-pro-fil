﻿using SendGrid;
using SendGrid.Helpers.Mail;

namespace ProScheduler.Api.Services;

public class EmailService : IEmailService
{
    private readonly IConfiguration _config;
    private readonly ILogger<EmailService> _logger;

    public EmailService(IConfiguration config, ILogger<EmailService> logger)
    {
        _config = config;
        _logger = logger;
    }

    public async Task SendPasswordResetEmailAsync(string toEmail, string resetLink)
    {
        var apiKey = _config["Smtp:ApiKey"];
        if (string.IsNullOrEmpty(apiKey))
        {
            _logger.LogError("SendGrid API Key is not configured.");
            return;
        }

        var client = new SendGridClient(apiKey);

        var from = new EmailAddress(
            _config["Smtp:FromEmail"],
            _config["Smtp:FromName"]);

        var to = new EmailAddress(toEmail);

        var subject = "Reset your password for ProScheduler";

        var htmlContent = $"<p>Hello,</p>" +
                          $"<p>Please reset your password by <a href='{resetLink}'>clicking here</a>.</p>" +
                          $"<p>If you did not request a password reset, please ignore this email.</p>" +
                          $"<p>Thanks,<br/>The ProScheduler Team</p>";
        var plainTextContent = $"Hello, Please reset your password by visiting this link: {resetLink}";

        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);

        try
        {
            var response = await client.SendEmailAsync(msg);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Password reset email sent successfully to {Email}", toEmail);
            }
            else
            {
                _logger.LogError("Failed to send email. Status code: {StatusCode}, Body: {Body}",
                    response.StatusCode,
                    await response.Body.ReadAsStringAsync());
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An exception occurred while sending an email.");
        }
    }
}