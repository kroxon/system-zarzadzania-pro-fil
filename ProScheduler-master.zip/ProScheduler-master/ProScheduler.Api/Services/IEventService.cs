﻿using ProScheduler.Api.Contracts.Event;

namespace ProScheduler.Api.Services;

public interface IEventService
{
    Task<Result<EventDto>> GetEventByIdAsync(int eventId);
    Task<IEnumerable<EventDto>> GetAllEventsAsync();
    Task<Result<EventDto>> CreateEventAsync(CreateEventDto createEventDto);
    Task<Result<EventDto>> UpdateEventAsync(int eventId, UpdateEventDto updateEventDto);
    Task<Result> PatchEventPersonsAsync(int eventId, PatchEventPersonsDto patchEventPersonsDto);
    Task DeleteEventAsync(int eventId);
}
