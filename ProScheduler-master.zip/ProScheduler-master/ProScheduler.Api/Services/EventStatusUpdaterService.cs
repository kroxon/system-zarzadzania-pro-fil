﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Services;

public class EventStatusUpdaterService : BackgroundService
{
    private readonly ILogger<EventStatusUpdaterService> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly TimeZoneInfo _polishTimeZone;

    public EventStatusUpdaterService(ILogger<EventStatusUpdaterService> logger, IServiceScopeFactory scopeFactory)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;

        try
        {
            _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        }
        catch (TimeZoneNotFoundException)
        {
            try
            {
                _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Europe/Warsaw");
            }
            catch (TimeZoneNotFoundException)
            {
                _logger.LogError("Polish time zone not found on this system.");
                throw new Exception("Polish time zone not found");
            }
        }
    }
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        _logger.LogInformation("Service is running.");

        while (!ct.IsCancellationRequested)
        {
            _logger.LogInformation("Checking statuses: {time}", DateTime.Now);

            try
            {
                using var scope = _scopeFactory.CreateScope();
                var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                await UpdateEventStatuses(dbContext, ct);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Service cancelled.");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected Error.");
            }

            var delay = CalculateNextRunDelay();
            await Task.Delay(delay, ct);
        }

        _logger.LogInformation("Service shutdown.");
    }

    private TimeSpan CalculateNextRunDelay()
    {
        const int intervalMinutes = 30;
        const int minuteOffset = 1;

        DateTime polishTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, _polishTimeZone);

        var currentMinute = polishTime.Minute;
        var currentSecond = polishTime.Second;

        int minutesToAdd = intervalMinutes - (currentMinute % intervalMinutes) + minuteOffset;
        int secondsToSubtract = currentSecond;

        return TimeSpan.FromMinutes(minutesToAdd) - TimeSpan.FromSeconds(secondsToSubtract);
    }

    private async Task UpdateEventStatuses(ApplicationDbContext dbContext, CancellationToken ct)
    {
        DateTime polishTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, _polishTimeZone);

        var plannedToInProgressCount = await dbContext.Events
        .Where(e => e.StatusId == StatusConstants.Planned && e.Start <= polishTime)
        .ExecuteUpdateAsync(
            setters => setters.SetProperty(e => e.StatusId, StatusConstants.InProgress),
            ct
        );

        var inProgressToCompletedCount = await dbContext.Events
        .Where(e => e.StatusId == StatusConstants.InProgress && e.End <= polishTime)
        .ExecuteUpdateAsync(
            setters => setters.SetProperty(e => e.StatusId, StatusConstants.Completed),
            ct
        );

        var totalUpdatedCount = inProgressToCompletedCount + plannedToInProgressCount;

        if (totalUpdatedCount > 0)
        {
            _logger.LogInformation("Updated {totalUpdatedCount} events.", totalUpdatedCount);
        }
    }
}
