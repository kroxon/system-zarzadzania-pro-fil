﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProScheduler.Api.Services.ReportServices;

public class PatientReportService
{
    private readonly ILogger<PatientReportService> _logger;
    private readonly ApplicationDbContext _db;
    private readonly TimeZoneInfo _polishTimeZone;

    public PatientReportService(ILogger<PatientReportService> logger, ApplicationDbContext db)
    {
        _logger = logger;
        _db = db;
        QuestPDF.Settings.License = LicenseType.Community;

        try
        {
            _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        }
        catch (TimeZoneNotFoundException)
        {
            try
            {
                _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Europe/Warsaw");
            }
            catch (TimeZoneNotFoundException)
            {
                _logger.LogError("Polish time zone not found on this system.");
                throw new Exception("Polish time zone not found");
            }
        }
    }
    public async Task<Result<(byte[] file, string name)>> GenerateReportAsync(int patientId)
    {
        var patient = await _db.Patients
            .Include(p => p.Events)
            .ThenInclude(e => e.Persons)
            .Include(p => p.Events)
            .ThenInclude(e => e.Status)
            .FirstOrDefaultAsync(p => p.Id == patientId);

        if (patient == null)
        {
            var error = Errors.PatientNotFound(patientId);
            _logger.LogWarning("GeneratePatientReportAsync failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var file = await Task.FromResult(Document.Create(container =>
        {
            container.Page(page =>
            {
                page.DefaultTextStyle(x => x.FontSize(12));

                page.Size(PageSizes.A4);
                page.Margin(30);

                page.Header().Element(container => ComposeHeader(container, patient));
                page.Content().Element(container => ComposeContent(container, patient));
                page.Footer().AlignCenter().Text(x =>
                {
                    x.CurrentPageNumber();
                    x.Span(" / ");
                    x.TotalPages();
                });
            });
        }).GeneratePdf());

        return (file, $"patient_{patient.Name}_{patient.Surname}_report.pdf");
    }

    void ComposeHeader(IContainer container, Patient patient)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(column =>
            {
                column.Item()
                    .Text($"Dane pacjenta:")
                    .FontSize(20).SemiBold();

                column.Item().Text(text =>
                {
                    text.Span("Imię i Nazwisko: ").SemiBold();
                    text.Span($"{patient.Name} {patient.Surname}");
                });


                var today = DateOnly.FromDateTime(DateTime.Today);
                var age = today.Year - patient.BirthDate.Year;
                if (patient.BirthDate > today.AddYears(-age))
                {
                    age--;
                }
                column.Item().Text(text =>
                {
                    text.Span("Wiek: ").SemiBold();
                    text.Span($"{age}");
                });

                column.Item().Text(text =>
                {
                    text.Span("Data: ").SemiBold();
                    text.Span($"{TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, _polishTimeZone)}");
                });
            });

            row.ConstantItem(75).Image("PRO-FIL-removebg-preview.png");
        });
    }

    void ComposeContent(IContainer container, Patient patient)
    {
        container.PaddingVertical(20).Column(column =>
        {
            column.Item().Element(container => ComposePatientNotes(container, patient));

            column.Spacing(20);

            column.Item().Element(container => ComposePatientStatistics(container, patient));

            column.Spacing(20);

            column.Item().Element(container => ComposeTable(container, patient));
        });
    }

    void ComposePatientNotes(IContainer container, Patient patient)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(column =>
            {
                column.Item()
                    .Text($"Notatki o pacjencie:")
                    .FontSize(16).SemiBold();

                column.Item().PaddingHorizontal(10).Text(text =>
                {
                    text.Span(patient.Info ?? "brak");
                });
            });
        });
    }

    void ComposePatientStatistics(IContainer container, Patient patient)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(); // Obecny
                columns.RelativeColumn(); // Nieobecny
                columns.RelativeColumn(); // Suma
                columns.RelativeColumn(); // Czas terapii
            });

            table.Header(header =>
            {
                header.Cell().Element(CellStyle).Text("Obecny");
                header.Cell().Element(CellStyle).Text("Nieobecny");
                header.Cell().Element(CellStyle).Text("Suma spotkań");
                header.Cell().Element(CellStyle).Text("Długość współpracy");

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .DefaultTextStyle(x => x
                    .SemiBold())
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Background(Colors.Grey.Lighten3)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            });

            var completedCount = patient.Events.Count(e => e.StatusId == StatusConstants.Completed);
            table
                .Cell()
                .Element(CellStyle)
                .Text(completedCount.ToString());

            var absentCount = patient.Events.Count(e => e.StatusId == StatusConstants.Absent);
            table
                .Cell()
                .Element(CellStyle)
                .Text(absentCount.ToString());

            var eventSum = completedCount + absentCount;
            table
                .Cell()
                .Element(CellStyle)
                .Text(eventSum.ToString());

            var finishedEvents = patient.Events.Where(e => e.StatusId == StatusConstants.Completed);
            var firstEvent = finishedEvents.MinBy(e => e.Start);
            var lastEvent = finishedEvents.MaxBy(e => e.Start);
            var therapyDuration = lastEvent?.Start - firstEvent?.Start;
            table
                .Cell()
                .Element(CellStyle)
                .Text(therapyDuration is not null 
                    ? $"{therapyDuration.Value.Days} dni"
                    : "-");

            static IContainer CellStyle(IContainer container)
            {
                return container
                .Border(1)
                .BorderColor(Colors.Black)
                .Padding(5)
                .AlignMiddle()
                .AlignCenter();
            }
        });
    }

    void ComposeTable(IContainer container, Patient patient)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(60); // Data Godzina
                columns.RelativeColumn(2); // Tytuł
                columns.RelativeColumn(3.5f); // Notatki
                columns.RelativeColumn(); // Terapeuta
                columns.RelativeColumn(); // Status
            });

            table.Header(header =>
            {
                header.Cell().Element(CellStyle).Text("Data\nGodzina");
                header.Cell().Element(CellStyle).Text("Tytuł");
                header.Cell().Element(CellStyle).Text("Notatki");
                header.Cell().Element(CellStyle).Text("Terapeuta");
                header.Cell().Element(CellStyle).Text("Status");

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .DefaultTextStyle(x => x
                    .SemiBold())
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Background(Colors.Grey.Lighten2)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            });

            foreach (var @event in patient.Events)
            {
                table
                    .Cell()
                    .Element(CellStyle)
                    .Text($"{@event.Start:d.MM.yyyy}\n{@event.Start:HH:mm} - {@event.End:HH:mm}")
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Name);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Info)
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(string.Join(",", @event.Persons.Where(p => p is Employee).Select(p => $"{p.Name} {p.Surname}")))
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Status.Name)
                    .FontSize(8);

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            }
        });
    }
}
