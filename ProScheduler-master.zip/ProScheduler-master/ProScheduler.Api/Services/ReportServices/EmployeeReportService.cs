﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProScheduler.Api.Services.ReportServices;

public class EmployeeReportService
{
    private readonly ILogger<EmployeeReportService> _logger;
    private readonly ApplicationDbContext _db;
    private readonly TimeZoneInfo _polishTimeZone;

    public EmployeeReportService(ILogger<EmployeeReportService> logger, ApplicationDbContext db)
    {
        _logger = logger;
        _db = db;
        QuestPDF.Settings.License = LicenseType.Community;

        try
        {
            _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        }
        catch (TimeZoneNotFoundException)
        {
            try
            {
                _polishTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Europe/Warsaw");
            }
            catch (TimeZoneNotFoundException)
            {
                _logger.LogError("Polish time zone not found on this system.");
                throw new Exception("Polish time zone not found");
            }
        }
    }

    public async Task<Result<(byte[] file, string name)>> GenerateReportAsync(int employeeId, int month, int year)
    {
        var employee = await _db.Employees
            .Include(e => e.Events.Where(e => e.Start.Month == month && e.Start.Year == year))
            .ThenInclude(e => e.Persons)
            .Include(e => e.Events)
            .ThenInclude(e => e.Status)
            .Include(e => e.WorkHours)
            .FirstOrDefaultAsync(e => e.Id == employeeId);

        if (employee == null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            _logger.LogWarning("GenerateEmployeeReportAsync failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var file = await Task.FromResult(Document.Create(container =>
        {
            container.Page(page =>
            {
                page.DefaultTextStyle(x => x.FontSize(12));

                page.Size(PageSizes.A4);
                page.Margin(30);

                page.Header().Element(container => ComposeHeader(container, employee, month, year));
                page.Content().Element(container => ComposeContent(container, employee));
                page.Footer().AlignCenter().Text(x =>
                {
                    x.CurrentPageNumber();
                    x.Span(" / ");
                    x.TotalPages();
                });
            });
        }).GeneratePdf());

        return (file, $"employee_{employee.Name}_{employee.Surname}_{month}_{year}_report.pdf");
    }

    void ComposeHeader(IContainer container, Employee employee, int month, int year)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(column =>
            {
                column.Item()
                    .Text($"Raport miesięczny pracownika {month}.{year}:")
                    .FontSize(20).SemiBold();

                column.Item()
                    .Text($"Dane pracownika:")
                    .FontSize(20).SemiBold();

                column.Item().Text(text =>
                {
                    text.Span("Imię i Nazwisko: ").SemiBold();
                    text.Span($"{employee.Name} {employee.Surname}");
                });

                column.Item().Text(text =>
                {
                    text.Span("Data: ").SemiBold();
                    text.Span($"{TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, _polishTimeZone)}");
                });
            });

            row.ConstantItem(75).Image("PRO-FIL-removebg-preview.png");
        });
    }

    void ComposeContent(IContainer container, Employee employee)
    {
        container.PaddingVertical(20).Column(column =>
        {
            column.Item().Element(container => ComposeEmployeeNotes(container, employee));

            column.Spacing(20);

            column.Item().Element(container => ComposeEmployeeStatistics(container, employee));

            column.Spacing(20);

            column.Item().Element(container => ComposeTable(container, employee));
        });
    }

    void ComposeEmployeeNotes(IContainer container, Employee employee)
    {
        container.Row(row =>
        {
            row.RelativeItem().Column(column =>
            {
                column.Item()
                    .Text($"Notatki o pracowniku:")
                    .FontSize(16).SemiBold();

                column.Item().PaddingHorizontal(10).Text(text =>
                {
                    text.Span(employee.Info ?? "brak");
                });
            });
        });
    }

    void ComposeEmployeeStatistics(IContainer container, Employee employee)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(); // Godziny Pracy
                columns.RelativeColumn(); // Godziny Spotkań
                columns.RelativeColumn(); // Ukończone Spotkania
                columns.RelativeColumn(); // Odwołane Spotkania
            });

            table.Header(header =>
            {
                header.Cell().Element(CellStyle).Text("Godziny Pracy");
                header.Cell().Element(CellStyle).Text("Godziny Spotkań");
                header.Cell().Element(CellStyle).Text("Ukończone Spotkania");
                header.Cell().Element(CellStyle).Text("Odwołane Spotkania");

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .DefaultTextStyle(x => x
                    .SemiBold())
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Background(Colors.Grey.Lighten3)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            });

            var workHoursCount = employee.WorkHours.Sum(wh => (wh.End - wh.Start).TotalHours);
            table
                .Cell()
                .Element(CellStyle)
                .Text(workHoursCount.ToString());


            var eventHourCount = employee.Events
                .Where(e => e.StatusId == StatusConstants.Completed)
                .Sum(e => (e.End - e.Start).TotalHours);
            table
                .Cell()
                .Element(CellStyle)
                .Text(eventHourCount.ToString("F1"));

            var finishedEventCount = employee.Events.Count(e => e.StatusId == StatusConstants.Completed);
            table
                .Cell()
                .Element(CellStyle)
                .Text(finishedEventCount.ToString());

            var cancelledEventCount = employee.Events.Count(e => e.StatusId == StatusConstants.Cancelled);
            table
                .Cell()
                .Element(CellStyle)
                .Text(cancelledEventCount.ToString());

            static IContainer CellStyle(IContainer container)
            {
                return container
                .Border(1)
                .BorderColor(Colors.Black)
                .Padding(5)
                .AlignMiddle()
                .AlignCenter();
            }
        });
    }

    void ComposeTable(IContainer container, Employee employee)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(60); // Data Godzina
                columns.RelativeColumn(2); // Tytuł
                columns.RelativeColumn(3.5f); // Notatki
                columns.RelativeColumn(); // Pacjent
                columns.RelativeColumn(); // Status
            });

            table.Header(header =>
            {
                header.Cell().Element(CellStyle).Text("Data\nGodzina");
                header.Cell().Element(CellStyle).Text("Tytuł");
                header.Cell().Element(CellStyle).Text("Notatki");
                header.Cell().Element(CellStyle).Text("Pacjent");
                header.Cell().Element(CellStyle).Text("Status");

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .DefaultTextStyle(x => x
                    .SemiBold())
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Background(Colors.Grey.Lighten2)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            });

            foreach (var @event in employee.Events)
            {
                table
                    .Cell()
                    .Element(CellStyle)
                    .Text($"{@event.Start:d.MM.yyyy}\n{@event.Start:HH:mm} - {@event.End:HH:mm}")
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Name);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Info)
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(string.Join(",", @event.Persons.Where(p => p is Patient).Select(p => $"{p.Name} {p.Surname}")))
                    .FontSize(8);

                table
                    .Cell()
                    .Element(CellStyle)
                    .Text(@event.Status.Name)
                    .FontSize(8);

                static IContainer CellStyle(IContainer container)
                {
                    return container
                    .Border(1)
                    .BorderColor(Colors.Black)
                    .Padding(5)
                    .AlignMiddle()
                    .AlignCenter();
                }
            }
        });
    }
}
