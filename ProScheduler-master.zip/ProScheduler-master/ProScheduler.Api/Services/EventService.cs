﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Event;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Services;

public class EventService(ApplicationDbContext db, AvailabilityService availabilityService, ILogger<EventService> logger) : IEventService
{
    public async Task<IEnumerable<EventDto>> GetAllEventsAsync()
    {
        return await db.Events.Include(e => e.Persons).Select(e => e.ToDto()).AsNoTracking().ToListAsync();
    }

    public async Task<Result<EventDto>> GetEventByIdAsync(int eventId)
    {
        var @event = await 
            db
            .Events
            .Include(e => e.Persons)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == eventId);
        if (@event is null)
        {
            var error = Errors.EventNotFound(eventId);
            logger.LogWarning("Event Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return @event.ToDto();
    }

    public async Task<Result<EventDto>> CreateEventAsync(CreateEventDto createEventDto)
    {
        var @event = createEventDto.ToEntity();

        if (createEventDto.RoomId is not null)
        {
            var isRoomAvailableResult = await availabilityService.IsRoomAvailableAsync(createEventDto.RoomId.Value, @event.Start, @event.End);
            if (!isRoomAvailableResult.IsSuccess)
            {
                var error = isRoomAvailableResult.Error;
                logger.LogWarning("Event creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (!isRoomAvailableResult.Value)
            {
                var error = Errors.RoomNotAvailable(createEventDto.RoomId.Value);
                logger.LogWarning("Event creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var availablePersonsResult = await availabilityService.GetAvailablePersonsAsync(
            createEventDto.ParticipantIds!,
            @event.Start,
            @event.End);

        if (!availablePersonsResult.IsSuccess)
        {
            var error = availablePersonsResult.Error;
            logger.LogWarning("Event creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        @event.Persons = availablePersonsResult.Value;
        db.Events.Add(@event);
        await db.SaveChangesAsync();
        return @event.ToDto();
    }

    public async Task<Result<EventDto>> UpdateEventAsync(int eventId, UpdateEventDto updateEventDto)
    {
        var updateEvent = updateEventDto.ToEntity(eventId);
        var @event = await db.Events.Include(e => e.Persons).FirstOrDefaultAsync(e => e.Id == eventId);
        if (@event is null)
        {
            var error = Errors.EventNotFound(eventId);
            logger.LogWarning("Event update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        if (updateEvent.RoomId is not null)
        {
            var isRoomAvailableResult = await availabilityService.IsRoomAvailableAsync(updateEvent.RoomId.Value, updateEvent.Start, updateEvent.End, eventId);
            if (!isRoomAvailableResult.IsSuccess)
            {
                var error = isRoomAvailableResult.Error;
                logger.LogWarning("Event update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (!isRoomAvailableResult.Value)
            {
                var error = Errors.RoomNotAvailable(updateEvent.RoomId.Value);
                logger.LogWarning("Event update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var personsToCheck = updateEventDto.ParticipantIds!.Except(@event.Persons.Select(p => p.Id)).ToHashSet();
        var availablePersonsResult = await availabilityService.GetAvailablePersonsAsync(
            personsToCheck,
            updateEvent.Start,
            updateEvent.End);

        if (!availablePersonsResult.IsSuccess)
        {
            var error = availablePersonsResult.Error;
            logger.LogWarning("Event update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }


        db.Entry(@event).CurrentValues.SetValues(updateEvent);
        var personsToBeInEvent = db.Persons.Where(p => updateEventDto.ParticipantIds!.Contains(p.Id)).ToHashSet();
        @event.Persons = personsToBeInEvent;
        await db.SaveChangesAsync();
        return @event.ToDto();
    }

    public async Task<Result> PatchEventPersonsAsync(int eventId, PatchEventPersonsDto patchEventPersonsDto)
    {
        if (patchEventPersonsDto.AddPersonsIds is null && patchEventPersonsDto.RemovePersonsIds is null)
        {
            var error = Errors.AddPersonsIdsAndRemovePersonsIdsEmpty();
            logger.LogWarning("Event persons patching failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var @event = await db.Events.Include(e => e.Persons).FirstOrDefaultAsync(e => e.Id == eventId);
        if (@event is null)
        {
            var error = Errors.EventNotFound(eventId);
            logger.LogWarning("Event persons patching failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        if (patchEventPersonsDto.RemovePersonsIds?.Count > 0)
        {
            var personsToRemove = db.Persons.Where(p => patchEventPersonsDto.RemovePersonsIds.Contains(p.Id)).ToHashSet();
            @event.Persons.ExceptWith(personsToRemove);
        }

        if (patchEventPersonsDto.AddPersonsIds?.Count > 0)
        {
            var personsToAddIds = patchEventPersonsDto.AddPersonsIds;
            personsToAddIds.ExceptWith(@event.Persons.Select(p => p.Id).ToHashSet());
            var availablePersonsResult = await availabilityService.GetAvailablePersonsAsync(
                personsToAddIds,
                @event.Start,
                @event.End);

            if (!availablePersonsResult.IsSuccess)
            {
                var error = availablePersonsResult.Error;
                logger.LogWarning("Event persons patching failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            @event.Persons.UnionWith(availablePersonsResult.Value);
        }

        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task DeleteEventAsync(int eventId)
    {
        await db.Events.Where(e => e.Id == eventId).ExecuteDeleteAsync();
    }
}
