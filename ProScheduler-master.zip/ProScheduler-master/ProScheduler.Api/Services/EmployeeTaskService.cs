﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;
using System.Security.Claims;

namespace ProScheduler.Api.Services;

public class EmployeeTaskService(ApplicationDbContext db, ILogger<EmployeeTaskService> logger)
{
    public async Task<IEnumerable<EmployeeTaskDto>> GetAllEmployeeTasksAsync()
    {
        return await db.EmployeeTasks.Include(et => et.AssignedEmployees).Select(e => e.ToDto()).AsNoTracking().ToListAsync();
    }

    public async Task<Result<EmployeeTaskDto>> GetEmployeeTaskById(int employeeTaskId)
    {
        var employeeTask = await db
            .EmployeeTasks
            .Where(et => et.Id == employeeTaskId)
            .Include(et => et.AssignedEmployees)
            .FirstOrDefaultAsync();

        if (employeeTask is null)
        {
            var error = Errors.EmployeeTaskNotFound(employeeTaskId);
            logger.LogWarning("Employee Task Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return employeeTask.ToDto();
    }

    public async Task<Result<EmployeeTaskDto>> CreateEmployeeTask(CreateEmployeeTaskDto createEmployeeTaskDto, ClaimsPrincipal currentUser)
    {
        var employeeTask = createEmployeeTaskDto.ToEntity();

        var employees = await db.Employees.ToHashSetAsync();
        var invalidIds = createEmployeeTaskDto.AssignedEmployeesIds!.Except(employees.Select(e => e.Id));
        if (invalidIds.Any())
        {
            var error = Errors.EmployeeNotFound(invalidIds.First());
            logger.LogError("Employee Task Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var employeesToAdd = employees.Where(e => createEmployeeTaskDto.AssignedEmployeesIds!.Contains(e.Id)).ToHashSet();

        var isAdmin = currentUser.IsInRole("Admin");
        if (!isAdmin)
        {
            if (!int.TryParse(currentUser.FindFirstValue("employeeId"), out var employeeId))
            {
                var error = Errors.EmployeeIdClaimMissing();
                logger.LogError("Employee Task creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (!employeesToAdd.Any(e => e.Id == employeeId))
            {
                var error = Errors.EmployeeTaskCreationUnauthorized();
                logger.LogError("Employee Task creation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        employeeTask.AssignedEmployees = employeesToAdd;
        db.EmployeeTasks.Add(employeeTask);
        await db.SaveChangesAsync();
        return employeeTask.ToDto();
    }

    public async Task<Result> UpdateEmployeeTask(int employeeTaskId, UpdateEmployeeTaskDto updateEmployeeTaskDto, ClaimsPrincipal currentUser)
    {
        var existingEmployeeTask = await db.EmployeeTasks
            .Where(et => et.Id == employeeTaskId)
            .Include(et => et.AssignedEmployees)
            .FirstOrDefaultAsync();

        if (existingEmployeeTask is null)
        {
            var error = Errors.EmployeeTaskNotFound(employeeTaskId);
            logger.LogError("Employee Task update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var isAdmin = currentUser.IsInRole("Admin");
        if (!isAdmin)
        {
            if (!int.TryParse(currentUser.FindFirstValue("employeeId"), out var employeeId))
            {
                var error = Errors.EmployeeIdClaimMissing();
                logger.LogError("Employee Task update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (!existingEmployeeTask.AssignedEmployees.Any(e => e.Id == employeeId) || !updateEmployeeTaskDto.AssignedEmployeesIds!.Any(id => id == employeeId))
            {
                var error = Errors.EmployeeTaskUpdateUnauthorized(employeeTaskId);
                logger.LogError("Employee Task update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var employees = await db.Employees.ToHashSetAsync();
        var invalidIds = updateEmployeeTaskDto.AssignedEmployeesIds!.Except(employees.Select(e => e.Id));
        if (invalidIds.Any())
        {
            var error = Errors.EmployeeNotFound(invalidIds.First());
            logger.LogError("Employee Task update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var updatedEmployeeTask = updateEmployeeTaskDto.ToEntity(employeeTaskId);
        updatedEmployeeTask.AssignedEmployees = employees.Where(e => updateEmployeeTaskDto.AssignedEmployeesIds!.Contains(e.Id)).ToHashSet();
        db.Entry(existingEmployeeTask).CurrentValues.SetValues(updatedEmployeeTask);
        existingEmployeeTask.AssignedEmployees = updatedEmployeeTask.AssignedEmployees;
        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task<Result> DeleteEmployeeTask(int employeeTaskId, ClaimsPrincipal currentUser)
    {
        var existingEmployeeTask = await db.EmployeeTasks
            .Where(et => et.Id == employeeTaskId)
            .Include(et => et.AssignedEmployees)
            .FirstOrDefaultAsync(et => et.Id == employeeTaskId);

        if (existingEmployeeTask is null)
        {
            var error = Errors.EmployeeTaskNotFound(employeeTaskId);
            logger.LogError("Employee Task deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var isAdmin = currentUser.IsInRole("Admin");
        if (!isAdmin)
        {
            if (!int.TryParse(currentUser.FindFirstValue("employeeId"), out var employeeId))
            {
                var error = Errors.EmployeeIdClaimMissing();
                logger.LogError("Employee Task deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (!existingEmployeeTask.AssignedEmployees.Any(e => e.Id == employeeId))
            {
                var error = Errors.EmployeeTaskDeletionUnauthorized(employeeTaskId);
                logger.LogError("Employee Task deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        db.EmployeeTasks.Remove(existingEmployeeTask);
        await db.SaveChangesAsync();
        return Result.Success();
    }
}
