﻿using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Contracts.Person.Employee;
using ProScheduler.Api.Contracts.WorkHours;
using System.Security.Claims;

namespace ProScheduler.Api.Services;

public interface IEmployeeService
{
    Task<IEnumerable<EmployeeDto>> GetAllEmployeesAsync();
    Task<Result<EmployeeDto>> GetEmployeeByIdAsync(int employeeId);
    Task<Result<IEnumerable<WorkHoursDto>>> GetEmployeeWorkHoursAsync(int employeeId);
    Task<Result<(byte[] file, string name)>> GenerateEmployeeReportAsync(int employeeId, int month, int year);
    Task<Result> UpdateEmployeeAsync(int employeeId, UpdateEmployeeDto updateEmployeeDto, ClaimsPrincipal currentUser);
    Task<Result> DeleteEmployeeAsync(int employeeId, ClaimsPrincipal currentUser);
    Task<Result> AssignPatientsToEmployeeAsync(int employeeId, AssignPatientsToEmployeeDto assignPatientsToEmployeeDto);
    Task<Result> UnassignPatientsFromEmployeeAsync(int employeeId, UnassignPatientsFromEmployeeDto unassignPatientsDto);
    Task<Result<IEnumerable<EmployeeTaskDto>>> GetEmployeeTasksAsync(int employeeId, ClaimsPrincipal currentUser);
}
