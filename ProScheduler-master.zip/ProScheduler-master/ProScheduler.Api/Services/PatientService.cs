﻿using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Person.Patient;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;
using ProScheduler.Api.Services.ReportServices;

namespace ProScheduler.Api.Services;

public class PatientService(
    ApplicationDbContext db, 
    PatientReportService patientReportService, 
    ILogger<PatientService> logger
    ) : IPatientService
{
    public async Task<IEnumerable<PatientDto>> GetAllPatientsAsync()
    {
        return await
            db
            .Patients
            .Include(p => p.AssignedEmployees)
            .Select(e => e.ToDto())
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<Result<PatientDto>> GetPatientByIdAsync(int patientId)
    {
        var patient = await
            db
            .Patients
            .Include(p => p.AssignedEmployees)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == patientId);

        if (patient is null)
        {
            var error = Errors.PatientNotFound(patientId);
            logger.LogWarning("Patient Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return patient.ToDto();
    }

    public async Task<Result<PatientDto>> CreatePatientAsync(CreatePatientDto createPatientDto)
    {
        var patient = createPatientDto.ToEntity();
        db.Patients.Add(patient);
        await db.SaveChangesAsync();
        return patient.ToDto();
    }

    public async Task<Result> UpdatePatientAsync(int patientId, UpdatePatientDto updatePatientDto)
    {
        var updatedPatient = updatePatientDto.ToEntity(patientId);
        var patient = await db.Patients.FirstOrDefaultAsync(e => e.Id == patientId);
        if (patient is null)
        {
            var error = Errors.PatientNotFound(patientId);
            logger.LogWarning("Patient update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        db.Entry(patient).CurrentValues.SetValues(updatedPatient);
        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task DeletePatientAsync(int patientId)
    {
        if (await db.Patients.Where(e => e.Id == patientId).ExecuteDeleteAsync() == 0)
        {
            var error = Errors.PatientNotFound(patientId);
            logger.LogWarning("Patient deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
        }
        else
        {
            logger.LogInformation("Patient with Id {PatientId} deleted successfully.", patientId);
        }
    }

    public async Task<Result<(byte[] file, string name)>> GeneratePatientReportAsync(int patientId)
    {
        var result = await patientReportService.GenerateReportAsync(patientId);
        if (!result.IsSuccess)
        {
            var error = result.Error;
            logger.LogWarning("Patient report generation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return result.Value;
    }
}
