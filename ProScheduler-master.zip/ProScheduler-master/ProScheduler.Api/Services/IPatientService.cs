﻿using ProScheduler.Api.Contracts.Person.Patient;

namespace ProScheduler.Api.Services;

public interface IPatientService
{
    Task<IEnumerable<PatientDto>> GetAllPatientsAsync();
    Task<Result<PatientDto>> GetPatientByIdAsync(int patientId);
    Task<Result<PatientDto>> CreatePatientAsync(CreatePatientDto createPatientDto);
    Task<Result> UpdatePatientAsync(int patientId, UpdatePatientDto updatePatientDto);
    Task DeletePatientAsync(int patientId);
    Task<Result<(byte[] file, string name)>> GeneratePatientReportAsync(int patientId);
}
