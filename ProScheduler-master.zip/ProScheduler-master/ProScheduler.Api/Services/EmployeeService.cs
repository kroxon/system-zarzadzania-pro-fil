﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Contracts.Person.Employee;
using ProScheduler.Api.Contracts.WorkHours;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;
using ProScheduler.Api.Models;
using ProScheduler.Api.Services.ReportServices;
using System.Security.Claims;

namespace ProScheduler.Api.Services;

public class EmployeeService(
    UserManager<ApplicationUser> userManager,
    ApplicationDbContext db, 
    EmployeeReportService employeeReportService,
    ILogger<EmployeeService> logger) : IEmployeeService
{
    public async Task<IEnumerable<EmployeeDto>> GetAllEmployeesAsync()
    {
        var employee = await db.Employees
            .Include(e => e.ApplicationUser)
                .ThenInclude(au => au.Occupation)
            .Include(e => e.ApplicationUser)
                .ThenInclude(au => au.UserRoles)
            .Include(e => e.AssignedPatients)
            .AsNoTracking()
            .ToListAsync();


        var usersWithRoleIds = employee
            .Select(e => (e.ApplicationUser, e.ApplicationUser.UserRoles?.Select(ur => ur.RoleId).ToArray() ?? Array.Empty<string>()))
            .ToArray();
        var employeesWithRoleNames = await GetUsersRolesNames(usersWithRoleIds);

        return employee.Select(e => e.ToDto(
            e.ApplicationUser, 
            e.ApplicationUser.Occupation, 
            employeesWithRoleNames.FirstOrDefault(er => er.au == e.ApplicationUser).roles,
            e.AssignedPatients.Select(p => p.Id).ToArray()
        )).ToArray();
    }

    public async Task<Result<EmployeeDto>> GetEmployeeByIdAsync(int employeeId)
    {
        var employee = await db.Employees
            .Include(e => e.ApplicationUser)
                .ThenInclude(au => au.Occupation)
            .Include(e => e.ApplicationUser)
                .ThenInclude(au => au.UserRoles)
            .Include(e => e.AssignedPatients)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == employeeId);

        if (employee is null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogWarning("Employee Access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var roleNames = await GetUsersRolesNames([(employee.ApplicationUser, employee.ApplicationUser.UserRoles.Select(ur => ur.RoleId).ToArray())]);

        return employee.ToDto(employee.ApplicationUser, employee.ApplicationUser.Occupation, roleNames.FirstOrDefault().roles, employee.AssignedPatients.Select(p => p.Id).ToArray());
    }

    private async Task<(ApplicationUser au, string[] roles)[]> GetUsersRolesNames((ApplicationUser au, string[] roles)[] users)
    {
        var rolesMap = await db.Roles
            .Select(r => new { r.Id, Name = r.Name! })
            .ToDictionaryAsync(r => r.Id, r => r.Name);

        return users.Select(u => (u.au, u.roles.Select(rid => rolesMap[rid]).ToArray())).ToArray();
    }

    public async Task<Result<IEnumerable<WorkHoursDto>>> GetEmployeeWorkHoursAsync(int employeeId)
    {
        var employee = await db.Employees
            .Include(e => e.WorkHours)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == employeeId);

        if (employee is null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogWarning("Employee Work Hours access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return employee.WorkHours.Select(wh => wh.ToDto()).ToArray();
    }

    public async Task<Result<(byte[] file, string name)>> GenerateEmployeeReportAsync(int employeeId, int month, int year)
    {
        var result = await employeeReportService.GenerateReportAsync(employeeId, month, year);
        if (!result.IsSuccess)
        {
            var error = result.Error;
            logger.LogWarning("Employee report generation failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return result.Value;
    }

    public async Task<Result> UpdateEmployeeAsync(int employeeId, UpdateEmployeeDto updateEmployeeDto, ClaimsPrincipal currentUser)
    {
        var isAdmin = currentUser.IsInRole("Admin");

        var employee = await db.Employees.Include(e => e.ApplicationUser).FirstOrDefaultAsync(e => e.Id == employeeId);
        if (employee is null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogWarning("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        if (!isAdmin)
        {
            var userId = userManager.GetUserId(currentUser);

            if (!(userId == employee.ApplicationUserId))
            {
                var error = Errors.EmployeeUpdateUnauthorized(employeeId);
                logger.LogError("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var updatedEmployee = updateEmployeeDto.ToEntity(employeeId, employee.ApplicationUserId);

        var emailExists = userManager.Users.Any(u => u.Email == updateEmployeeDto.Email && u.Id != employee.ApplicationUserId);
        if (emailExists)
        {
            var error = Errors.EmailAlreadyExists(updateEmployeeDto.Email!);
            logger.LogWarning("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var occupation = await GetOccupationByIdAsync(updateEmployeeDto.OccupationId!.Value);
        if (!occupation.IsSuccess)
        {
            var error = occupation.Error;
            logger.LogWarning("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var user = await userManager.FindByIdAsync(employee.ApplicationUserId);
        if (user is null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogWarning("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        await using var transaction = await db.Database.BeginTransactionAsync();

        try 
        {
            db.Entry(employee).CurrentValues.SetValues(updatedEmployee);
            db.Entry(employee.ApplicationUser).CurrentValues.SetValues(new
            {
                updatedEmployee.Name,
                updatedEmployee.Surname,
                OccupationId = updateEmployeeDto.OccupationId!.Value
            });



            var setEmailResult = await userManager.SetEmailAsync(user, updateEmployeeDto.Email!);
            if (!setEmailResult.Succeeded)
            {
                var error = Errors.EmployeeUpdateFailed(employeeId, string.Join("; ", setEmailResult.Errors.Select(e => e.Description)));
                logger.LogError("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                await transaction.RollbackAsync();
                return error;
            }

            var setUsernameResult = await userManager.SetUserNameAsync(user, updateEmployeeDto.Email!);
            if (!setUsernameResult.Succeeded)
            {
                var error = Errors.EmployeeUpdateFailed(employeeId, string.Join("; ", setUsernameResult.Errors.Select(e => e.Description)));
                logger.LogError("Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                await transaction.RollbackAsync();
                return error;
            }
            user.EmailConfirmed = true;

            await db.SaveChangesAsync();
            await transaction.CommitAsync();
            return Result.Success();
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            var error = Errors.EmployeeUpdateFailed(employeeId, ex.Message);
            logger.LogError(ex, "Employee update failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }
    }

    public async Task<Result> DeleteEmployeeAsync(int employeeId, ClaimsPrincipal currentUser)
    {
        var isAdmin = currentUser.IsInRole("Admin");

        var employeeToDelete = await db.Employees
            .Include(e => e.ApplicationUser)
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == employeeId);

        if (employeeToDelete is null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogWarning("Employee deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return Result.Success();
        }

        if (!isAdmin)
        {
            var userId = userManager.GetUserId(currentUser);

            if (!(userId == employeeToDelete.ApplicationUserId))
            {
                var error = Errors.EmployeeDeletionUnauthorized(employeeId);
                logger.LogError("Employee deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var result = await userManager.DeleteAsync(employeeToDelete.ApplicationUser);
        if (!result.Succeeded)
        {
            var error = Errors.EmployeeDeletionFailed(employeeId, string.Join("; ", result.Errors.Select(e => e.Description)));
            logger.LogError("Employee deletion failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            throw new InvalidOperationException($"Failed to delete employee user account with ID {employeeId}. Details: {error.Description}");
        }
        else
        {
            logger.LogInformation("Employee with Id {EmployeeId} deleted successfully.", employeeId);
            return Result.Success();
        }
    }

    public async Task<Result<IEnumerable<EmployeeTaskDto>>> GetEmployeeTasksAsync(int employeeId, ClaimsPrincipal currentUser)
    {
        var isAdmin = currentUser.IsInRole("Admin");
        if (!isAdmin)
        {
            var employee = await db.Employees.FirstOrDefaultAsync(e => e.Id == employeeId);
            if (employee is null)
            {
                var error = Errors.EmployeeNotFound(employeeId);
                logger.LogWarning("Employee Tasks access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }

            if (userManager.GetUserId(currentUser) != employee.ApplicationUserId)
            {
                var error = Errors.EmployeeTasksAccessUnauthorized(employeeId);
                logger.LogError("Employee Tasks access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                    error.Id, error.Type, error.Description);
                return error;
            }
        }

        var tasks = await db.EmployeeTasks
            .Where(et => et.AssignedEmployees.Any(e => e.Id == employeeId))
            .Include(et => et.AssignedEmployees)
            .AsNoTracking()
            .ToListAsync();
        return tasks.Select(t => t.ToDto()).ToArray();
    }

    public async Task<Result> AssignPatientsToEmployeeAsync(int employeeId, AssignPatientsToEmployeeDto assignPatientsDto)
    {
        var employee = await db.Employees.FindAsync(employeeId);
        if (employee == null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogError("Assigning patients to employee failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var patients = await db.Patients.Where(p => assignPatientsDto.PatientIds!.Contains(p.Id)).ToListAsync();
        if (patients.Count != assignPatientsDto.PatientIds!.Count)
        {
            var missingIds = assignPatientsDto.PatientIds.Except(patients.Select(p => p.Id)).ToList();
            var error = Errors.PatientNotFound(missingIds.FirstOrDefault());
            logger.LogError("Assigning patients to employee failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        employee.AssignedPatients = patients;
        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task<Result> UnassignPatientsFromEmployeeAsync(int employeeId, UnassignPatientsFromEmployeeDto unassignPatientsDto)
    {
        var employee = await db.Employees
            .Include(p => p.AssignedPatients)
            .FirstOrDefaultAsync(e => e.Id == employeeId);

        if (employee == null)
        {
            var error = Errors.EmployeeNotFound(employeeId);
            logger.LogError("Unassigning patients from employee failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        var patients = await db.Patients.Where(p => unassignPatientsDto.PatientIds!.Contains(p.Id)).ToListAsync();
        if (patients.Count != unassignPatientsDto.PatientIds!.Count)
        {
            var missingIds = unassignPatientsDto.PatientIds.Except(patients.Select(p => p.Id)).ToList();
            var error = Errors.PatientNotFound(missingIds.FirstOrDefault());
            logger.LogError("Unassigning patients from employee failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        foreach (var patient in patients)
        {
            employee.AssignedPatients.Remove(patient);
        }

        await db.SaveChangesAsync();
        return Result.Success();
    }

    private async Task<Result<Occupation>> GetOccupationByIdAsync(int occupationId)
    {
        var ocupation = await db.Occupations.Where(o => o.Id == occupationId).FirstOrDefaultAsync();
        if (ocupation == null)
        {
            var error = Errors.OccupationNotFound(occupationId);
            logger.LogWarning("Occupation access failed. Error Id: {ErrorId}, Type: {ErrorType}, Description: {ErrorDescription}",
                error.Id, error.Type, error.Description);
            return error;
        }

        return ocupation;
    }
}