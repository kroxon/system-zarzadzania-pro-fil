﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.EventStatus;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;

namespace ProScheduler.Api.Endpoints;

public static class EventStatuses
{
    public static RouteGroupBuilder MapEventStatusesEndpoints(this WebApplication app)
    {
        const string GetEventStatusEndpointName = "GetEventStatus";
        var group = app.MapGroup("/api/event-statuses")
            .WithTags("EventStatuses")
            .WithParameterValidation();

        // GET /api/event-statuses
        _ = group.MapGet("/", async (ApplicationDbContext db) =>
            TypedResults.Ok(await db.EventStatuses.Select(status => status.ToDto()).AsNoTracking().ToListAsync()));

        // GET /api/event-statuses/{id}
        _ = group.MapGet("/{id:int}", async Task<Results<NotFound, Ok<EventStatusDto>>> (int id, ApplicationDbContext db) =>
        {
            var status = await db.EventStatuses.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
            return status is null ? TypedResults.NotFound() : TypedResults.Ok(status.ToDto());
        })
        .WithName(GetEventStatusEndpointName);

        return group;
    }
}
