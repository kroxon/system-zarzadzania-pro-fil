﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using ProScheduler.Api.Contracts.Event;
using ProScheduler.Api.Contracts.Statistic;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class StatisticsApi
{
    const string Tag = "Statistics";
    const string BasePath = "/api/statistics";

    public static RouteGroupBuilder MapStatisticsEndpoints(this WebApplication app)
    {
        var group = app.MapGroup(BasePath)
            .WithTags(Tag)
            .WithParameterValidation();

        // GET /api/statistics/main-panel
        group.MapGet("/main-panel", HandleGetMainPanelStatisticsAsync);

        // GET /api/statistics/
        group.MapGet("/", HandleGetAllStatisticsAsync)
            .RequireAuthorization("AdminOnly");

        // GET /api/statistics/me
        group.MapGet("/me", HandleGetStatisticsAsync);

        return group;
    }

    private static async Task<Ok<MainPanelStatisticDto>> HandleGetMainPanelStatisticsAsync(StatisticsService statisticsService)
    {
        return TypedResults.Ok(await statisticsService.GetMainPanelStatisticsAsync());
    }

    private static async Task<Ok<List<EmployeeStatisticDto>>> HandleGetAllStatisticsAsync(
        [FromQuery] int year, 
        [FromQuery] int? month, 
        StatisticsService statisticsService)
    {
        return TypedResults.Ok(await statisticsService.GetEventStatisticsAsync(year, month));
    }

    private static async Task<Ok<List<EmployeeStatisticDto>>> HandleGetStatisticsAsync(
        [FromQuery] int year,
        [FromQuery] int? month, 
        StatisticsService statisticsService, 
        HttpContext httpContext)
    {
        var employeeIdClaim = httpContext.User.Claims.FirstOrDefault(c => c.Type == "employeeId");
        if (employeeIdClaim == null || !int.TryParse(employeeIdClaim.Value, out int employeeId))
        {
            throw new UnauthorizedAccessException("Employee ID claim is missing or invalid.");
        }
        return TypedResults.Ok(await statisticsService.GetEventStatisticsAsync(year, month, employeeId));
    }
}
