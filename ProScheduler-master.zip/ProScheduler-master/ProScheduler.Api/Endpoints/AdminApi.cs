﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Auth;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Endpoints;

public static class AdminApi
{
    public static RouteGroupBuilder MapAdminEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin")
            .WithTags("Admin")
            .RequireAuthorization("AdminOnly");

        // GET /api/admin/pending-users
        group.MapGet("/pending-users", HandleGetPendingUsersAsync);

        // POST /api/admin/approve-user/{userId}
        group.MapPost("/approve-user/{userId}", HandleApproveUserAsync);

        // POST /api/admin/reject-user/{userId}
        group.MapDelete("/reject-user/{userId}", HandleRejectUserAsync);

        return group;
    }

    private static async Task<Ok<List<PendingUserDto>>> HandleGetPendingUsersAsync(
        UserManager<ApplicationUser> userManager)
    {
        var pendingUsers = await userManager.Users
            .Where(u => !u.EmailConfirmed)
            .Include(u => u.Occupation)
            .ToListAsync();

        var dtos = new List<PendingUserDto>();
        foreach (var user in pendingUsers)
        {
            dtos.Add(new PendingUserDto
            { 
                Id = user.Id,
                Name = user.Name,
                Surname = user.Surname,
                Email = user.Email!,
                OccupationName = user.Occupation.Name,
            });
        }

        return TypedResults.Ok(dtos);
    }

    private static async Task<Results<NoContent, NotFound, ValidationProblem>> HandleApproveUserAsync(
        string userId,
        ApproveUserDto approveUserDto,
        UserManager<ApplicationUser> userManager,
        ApplicationDbContext dbContext
        /*ILogger logger*/)
    {
        var user = await userManager.FindByIdAsync(userId);
        if (user is null || user.EmailConfirmed)
        {
            return TypedResults.NotFound();
        }

        var addRoleResult = await userManager.AddToRoleAsync(user, approveUserDto.Role.ToString()!);

        if (!addRoleResult.Succeeded)
        {
            return TypedResults.ValidationProblem(addRoleResult.Errors.ToDictionary(e => e.Code, e => new[] { e.Description }));
        }

        var employee = new Employee
        {
            Name = user.Name,
            Surname = user.Surname,
            ApplicationUserId = user.Id
        };

        dbContext.Employees.Add(employee);
        await dbContext.SaveChangesAsync();

        user.EmailConfirmed = true;

        var result = await userManager.UpdateAsync(user);

        if (!result.Succeeded)
        {
            dbContext.Employees.Remove(employee);
            await dbContext.SaveChangesAsync();

            //logger.LogError("Failed to update user {UserId} after approving. Errors: {Errors}", user.Id, string.Join(", ", result.Errors.Select(e => e.Description)));
            throw new Exception("Failed to update user");
        }

        return TypedResults.NoContent();
    }

    private static async Task<Results<NoContent, NotFound>> HandleRejectUserAsync(
        string userId,
        UserManager<ApplicationUser> userManager)
    {
        var user = await userManager.FindByIdAsync(userId);
        if (user is null || user.EmailConfirmed)
        {
            return TypedResults.NotFound();
        }

        await userManager.DeleteAsync(user);

        return TypedResults.NoContent();
    }
}
