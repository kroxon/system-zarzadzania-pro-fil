﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Occupation;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;

namespace ProScheduler.Api.Endpoints;

public static class OccupationsApi
{
    public static RouteGroupBuilder MapOccupationsEndpoints(this WebApplication app)
    {
        const string GetOccupationEndpointName = "GetOccupation";
        var group = app.MapGroup("/api/occupations")
            .WithTags("Occupations")
            .WithParameterValidation();

        // Get /api/occupations
        group.MapGet("/", async (ApplicationDbContext db) =>
        {
            var dtos = await db.Occupations.Select(occupation => occupation.ToDto()).AsNoTracking().ToListAsync();
            dtos.Reverse();
            return TypedResults.Ok(dtos);
        })
            .AllowAnonymous();

        // GET /api/occupations/{id}
        group.MapGet("/{id:int}", async Task<Results<NotFound, Ok<OccupationDto>>> (int id, ApplicationDbContext db) =>
        {
            var occupation = await db.Occupations.AsNoTracking().FirstOrDefaultAsync(o => o.Id == id);
            return occupation is null ? TypedResults.NotFound() : TypedResults.Ok(occupation.ToDto());
        })
        .WithName(GetOccupationEndpointName);

        // POST /api/occupations
        group.MapPost("/", async Task<CreatedAtRoute<OccupationDto>> (CreateOccupationDto createOccupationDto, ApplicationDbContext db) =>
        {
            var occupation = createOccupationDto.ToEntity();
            db.Occupations.Add(occupation);
            await db.SaveChangesAsync();
            return TypedResults.CreatedAtRoute(occupation.ToDto(), GetOccupationEndpointName, new { id = occupation.Id });
        })
            .RequireAuthorization("AdminOnly");

        // DELETE /api/occupations/{id}
        group.MapDelete("/{id:int}", async Task<Results<NotFound, NoContent>> (int id, ApplicationDbContext db) =>
        {
            await db.Occupations.Where(occupation => occupation.Id == id).ExecuteDeleteAsync();
            return TypedResults.NoContent();
        })
            .RequireAuthorization("AdminOnly");

        // PUT /api/occupations/{id}
        group.MapPut("/{id:int}", async Task<Results<NotFound, NoContent>> (int id, UpdateOccupationDto updateOccupationDto, ApplicationDbContext db) =>
        {
            var occupation = await db.Occupations.FindAsync(id);
            if (occupation is null)
            {
                return TypedResults.NotFound();
            }

            db.Entry(occupation).CurrentValues.SetValues(updateOccupationDto.ToEntity(id));
            await db.SaveChangesAsync();
            return TypedResults.NoContent();
        })
            .RequireAuthorization("AdminOnly");

        return group;
    }
}
