﻿using Microsoft.AspNetCore.Http.HttpResults;
using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Contracts.Person.Employee;
using ProScheduler.Api.Contracts.WorkHours;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class EmployeesApi
{
    const string GetEmployeeEndpointName = "GetEmployee";
    public static RouteGroupBuilder MapEmployeesEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/employees")
            .WithTags("Employees")
            .WithParameterValidation();

        // GET /api/employees
        group.MapGet("/", HandleGetEmployeesAsync);

        // GET /api/employees/{id}
        group.MapGet("/{id:int}", HandleGetEmployeeByIdAsync)
            .WithName(GetEmployeeEndpointName);

        // GET /api/employees/{id}/work-hours
        group.MapGet("/{id:int}/work-hours", HandleGetEmployeeWorkHoursAsync);

        // GET /api/employees/{id}/tasks
        group.MapGet("/{id:int}/tasks", HandleGetEmployeeTasksAsync);

        // GET /api/employees/{id}/report
        group.MapGet("/{id:int}/report", HandleGetEmployeeReportAsync)
            .Produces(StatusCodes.Status200OK, typeof(byte[]), "application/pdf");

        // PUT /api/employees/{id}
        group.MapPut("/{id:int}", HandleUpdateEmployeeAsync);

        // DELETE /api/employees/{id}
        group.MapDelete("/{id:int}", HandleDeleteEmployeeAsync);

        // POST /api/employees/{id}/assign-patients
        group.MapPost("/{id:int}/assign-patients", HandleAssignPatientsToEmployeeAsync);

        // POST /api/employees/{id}/unassign-patients
        group.MapPost("/{id:int}/unassign-patients", HandleUnassignPatientsFromEmployeeAsync);

        return group;
    }

    private static async Task<Ok<IEnumerable<EmployeeDto>>> HandleGetEmployeesAsync(IEmployeeService employeeService)
    {
        return TypedResults.Ok(await employeeService.GetAllEmployeesAsync());
    }

    private static async Task<Results<NotFound<string>, Ok<EmployeeDto>>> HandleGetEmployeeByIdAsync(int id, IEmployeeService employeeService)
    {
        var serviceResponse = await employeeService.GetEmployeeByIdAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, Ok<IEnumerable<WorkHoursDto>>>> HandleGetEmployeeWorkHoursAsync(int id, IEmployeeService employeeService)
    {
        var serviceResponse = await employeeService.GetEmployeeWorkHoursAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, Ok<IEnumerable<EmployeeTaskDto>>, ForbidHttpResult>> HandleGetEmployeeTasksAsync(int id, IEmployeeService employeeService, HttpContext context)
    {
        var serviceResponse = await employeeService.GetEmployeeTasksAsync(id, context.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, FileContentHttpResult>> HandleGetEmployeeReportAsync(int id, int month, int year, IEmployeeService employeeService)
    {
        var serviceResponse = await employeeService.GenerateEmployeeReportAsync(id, month, year);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.File(serviceResponse.Value.file, "application/pdf", serviceResponse.Value.name),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, BadRequest<string>, NoContent, ForbidHttpResult>> HandleUpdateEmployeeAsync(int id, UpdateEmployeeDto updateEmployeeDto, IEmployeeService employeeService, HttpContext context)
    {
        var serviceResponse = await employeeService.UpdateEmployeeAsync(id, updateEmployeeDto, context.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NoContent, ForbidHttpResult>> HandleDeleteEmployeeAsync(int id, IEmployeeService employeeService, HttpContext context)
    {
        var serviceResponse = await employeeService.DeleteEmployeeAsync(id, context.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, NoContent>> HandleAssignPatientsToEmployeeAsync(int id, AssignPatientsToEmployeeDto assignPatientsToEmployeeDto, IEmployeeService employeeService)
    {
        var serviceResponse = await employeeService.AssignPatientsToEmployeeAsync(id, assignPatientsToEmployeeDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, NoContent>> HandleUnassignPatientsFromEmployeeAsync(int id, UnassignPatientsFromEmployeeDto unassignPatientsDto, IEmployeeService employeeService)
    {
        var serviceResponse = await employeeService.UnassignPatientsFromEmployeeAsync(id, unassignPatientsDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }
}
