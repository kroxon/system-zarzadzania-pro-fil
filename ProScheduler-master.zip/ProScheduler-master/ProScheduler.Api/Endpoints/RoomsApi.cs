﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Contracts.Room;
using ProScheduler.Api.Data;
using ProScheduler.Api.Extensions.ModelDtoMappings;

namespace ProScheduler.Api.Endpoints;

public static class RoomsApi
{
    public static RouteGroupBuilder MapRoomsEndpoints(this WebApplication app)
    {
        const string GetRoomEndpointName = "GetRoom";
        var group = app.MapGroup("/api/rooms")
            .WithTags("Rooms")
            .WithParameterValidation();

        // GET /api/rooms
        group.MapGet("/", async (ApplicationDbContext db) =>
            TypedResults.Ok(await db.Rooms.Select(room => room.ToDto()).AsNoTracking().ToListAsync()));

        // GET /api/rooms/{id}
        group.MapGet("/{id:int}", async Task<Results<NotFound, Ok<RoomDto>>> (int id, ApplicationDbContext db) =>
        {
            var room = await db.Rooms.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id);
            return room is null ? TypedResults.NotFound() : TypedResults.Ok(room.ToDto());
        })
        .WithName(GetRoomEndpointName);

        // POST /api/rooms
        group.MapPost("/", async (CreateRoomDto createRoomDto, ApplicationDbContext db) =>
        {
            var room = createRoomDto.ToEntity();
            db.Rooms.Add(room);
            await db.SaveChangesAsync();
            return TypedResults.CreatedAtRoute(room.ToDto(), GetRoomEndpointName, new { id = room.Id });
        });

        // DELETE /api/rooms/{id}
        group.MapDelete("/{id:int}", async (int id, ApplicationDbContext db) =>
        {
            //await db.Rooms.Where(room => room.Id == id).ExecuteDeleteAsync();
            db.Rooms.Remove(new() { Id = id, HexColor = string.Empty, Name = string.Empty});
            await db.SaveChangesAsync();
            return TypedResults.NoContent();
        });

        // PUT /api/rooms/{id}
        group.MapPut("/{id:int}", async Task<Results<NotFound, NoContent>> (int id, UpdateRoomDto updateRoomDto, ApplicationDbContext db) =>
        {
            var room = await db.Rooms.FindAsync(id);
            if (room is null)
            {
                return TypedResults.NotFound();
            }

            var updatedRoom = updateRoomDto.ToEntity(id);
            db.Entry(room).CurrentValues.SetValues(updatedRoom);
            await db.SaveChangesAsync();
            return TypedResults.NoContent();
        });

        return group;
    }
}
