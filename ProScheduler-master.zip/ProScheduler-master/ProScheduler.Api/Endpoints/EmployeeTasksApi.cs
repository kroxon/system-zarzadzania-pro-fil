﻿using Microsoft.AspNetCore.Http.HttpResults;
using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class EmployeeTasksApi
{
    private const string GetEmployeeTaskEndpointName = "GetEmployeeTask";
    public static RouteGroupBuilder MapEmployeeTasksEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/employeetasks")
            .WithTags("EmployeeTasks")
            .WithParameterValidation();

        // GET /api/employeetasks
        group.MapGet("/", HandleGetEmployeeTasksAsync);

        // GET /api/employeetasks/{id}
        group.MapGet("/{id:int}", HandleGetEmployeeTaskByIdAsync)
            .WithName(GetEmployeeTaskEndpointName);

        // POST /api/employeetasks
        group.MapPost("/", HandlePostEmployeeTaskAsync);

        // PUT /api/employeetasks/{id}
        group.MapPut("/{id:int}", HandleUpdateEmployeeTaskAsync);

        // DELETE /api/employeetasks/{id}
        group.MapDelete("/{id:int}", HandleDeleteEmployeeTaskAsync);

        return group;
    }

    private static async Task<Ok<IEnumerable<EmployeeTaskDto>>> HandleGetEmployeeTasksAsync(EmployeeTaskService employeeTaskService)
    {
        return TypedResults.Ok(await employeeTaskService.GetAllEmployeeTasksAsync());
    }

    private static async Task<Results<NotFound<string>, Ok<EmployeeTaskDto>>> HandleGetEmployeeTaskByIdAsync(int id, EmployeeTaskService employeeTaskService)
    {
        var serviceResponse = await employeeTaskService.GetEmployeeTaskById(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, CreatedAtRoute<EmployeeTaskDto>, ForbidHttpResult>> HandlePostEmployeeTaskAsync(CreateEmployeeTaskDto createEmployeeTaskDto, EmployeeTaskService employeeTaskService, HttpContext httpContext)
    {
        var serviceResponse = await employeeTaskService.CreateEmployeeTask(createEmployeeTaskDto, httpContext.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.CreatedAtRoute(serviceResponse.Value, GetEmployeeTaskEndpointName, new { id = serviceResponse.Value.Id }),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, NoContent, ForbidHttpResult>> HandleUpdateEmployeeTaskAsync(int id, UpdateEmployeeTaskDto updateEmployeeTaskDto, EmployeeTaskService employeeTaskService, HttpContext httpContext)
    {
        var serviceResponse = await employeeTaskService.UpdateEmployeeTask(id, updateEmployeeTaskDto, httpContext.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NoContent, ForbidHttpResult>> HandleDeleteEmployeeTaskAsync(int id, EmployeeTaskService employeeTaskService, HttpContext httpContext)
    {
        var serviceResponse = await employeeTaskService.DeleteEmployeeTask(id, httpContext.User);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.Forbidden } => TypedResults.Forbid(),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }
}
