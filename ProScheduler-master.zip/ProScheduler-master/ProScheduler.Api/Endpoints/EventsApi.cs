﻿using Microsoft.AspNetCore.Http.HttpResults;
using ProScheduler.Api.Contracts.Event;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class EventsApi
{
    private const string GetEventEndpointName = "GetEvent";
    public static RouteGroupBuilder MapEventsEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/events")
            .WithTags("Events")
            .WithParameterValidation();

        // GET /api/events
        group.MapGet("/", HandleGetEventAsync);

        // GET /api/events/{id}
        group.MapGet("/{id:int}", HandleGetEventByIdAsync)
            .WithName(GetEventEndpointName);

        // POST /api/events
        group.MapPost("/", HandlePostEventAsync);

        // DELETE /api/events/{id}
        group.MapDelete("/{id:int}", HandleDeleteEventAsync);

        // PUT /api/events/{id}
        group.MapPut("/{id:int}", HandleUpdateEventAsync);

        // PATCH /api/events/{id}/persons
        group.MapPatch("/{eventId:int}/persons", HandlePatchEventPersonsAsync);

        return group;
    }

    public static async Task<Ok<IEnumerable<EventDto>>> HandleGetEventAsync(IEventService eventService)
    {
        return TypedResults.Ok(await eventService.GetAllEventsAsync());
    }

    public static async Task<Results<NotFound<string>, Ok<EventDto>>> HandleGetEventByIdAsync(int id, IEventService eventService)
    {
        var serviceResponse = await eventService.GetEventByIdAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, BadRequest<string>, CreatedAtRoute<EventDto>>> HandlePostEventAsync(CreateEventDto createEventDto, IEventService eventService)
    {
        var serviceResponse = await eventService.CreateEventAsync(createEventDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.CreatedAtRoute(serviceResponse.Value, GetEventEndpointName, new { id = serviceResponse.Value.Id }),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }
    private static async Task<NoContent> HandleDeleteEventAsync(int id, IEventService eventService)
    {
        await eventService.DeleteEventAsync(id);
        return TypedResults.NoContent();
    }

    private static async Task<Results<NotFound<string>, BadRequest<string>, NoContent>> HandleUpdateEventAsync(int id, UpdateEventDto updateEventDto, IEventService eventService)
    {
        var serviceResponse = await eventService.UpdateEventAsync(id, updateEventDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<BadRequest<string>, NotFound<string>, NoContent>> HandlePatchEventPersonsAsync(int eventId, PatchEventPersonsDto patchEventPersonsDto, IEventService eventService)
    {
        var serviceResponse = await eventService.PatchEventPersonsAsync(eventId, patchEventPersonsDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }
}
