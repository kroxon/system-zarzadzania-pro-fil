﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ProScheduler.Api.Contracts.Auth;
using ProScheduler.Api.Data;
using ProScheduler.Api.Models;
using ProScheduler.Api.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Web;

namespace ProScheduler.Api.Endpoints;

public static class AuthApi
{
    public static RouteGroupBuilder MapAuthEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/auth")
            .WithTags("Auth")
            .WithParameterValidation()
            .AllowAnonymous();

        // POST /api/auth/register
        group.MapPost("/register", HandleRegisterAsync);

        // POST /api/auth/login
        group.MapPost("/login", HandleLoginAsync);

        // POST /api/auth/forgot-password
        group.MapPost("/forgot-password", HandleForgotPasswordAsync);

        // POST /api/auth/reset-password
        group.MapPost("/reset-password", HandleResetPasswordAsync);

        return group;
    }

    private static async Task<Results<Ok, ValidationProblem>> HandleRegisterAsync(
        RegisterDto registerDto,
        UserManager<ApplicationUser> userManager,
        ApplicationDbContext dbContext)
    {
        var userExists = await userManager.FindByEmailAsync(registerDto.Email!) is not null;
        if (userExists)
        {
            return TypedResults.ValidationProblem(new Dictionary<string, string[]>
            {
                { "DuplicateEmail", new[] { "A user with this email already exists." } }
            });
        }

        var occupationExists = await dbContext.Occupations.AnyAsync(o => o.Id == registerDto.OccupationId);
        if (!occupationExists)
        {
            return TypedResults.ValidationProblem(new Dictionary<string, string[]>
            {
                { "InvalidOccupationId", new[] { "The specified occupation does not exist." } }
            });
        }

        var user = new ApplicationUser
        {
            UserName = registerDto.Email,
            Email = registerDto.Email,
            Name = registerDto.Name!,
            Surname = registerDto.Surname!,
            OccupationId = registerDto.OccupationId!.Value
        };

        var result = await userManager.CreateAsync(user, registerDto.Password!);

        if (!result.Succeeded)
        {
            return TypedResults.ValidationProblem(result.Errors.ToDictionary(e => e.Code, e => new[] { e.Description }));
        }

        return TypedResults.Ok();
    }

    private static async Task<Results<Ok<AuthResponseDto>, UnauthorizedHttpResult>> HandleLoginAsync(
        LoginDto loginDto,
        UserManager<ApplicationUser> userManager,
        IConfiguration configuration
        /*ILogger logger*/)
    {
            var user = await userManager.Users
            .Include(u => u.Employee)
            .FirstOrDefaultAsync(u => u.Email == loginDto.Email);

        if (user is null || !await userManager.CheckPasswordAsync(user, loginDto.Password!))
        {
            //logger.LogWarning("Failed login attempt. Email: {Email}", loginDto.Email);
            return TypedResults.Unauthorized();
        }

        if (!user.EmailConfirmed)
        {
            //logger.LogWarning("Attempt to login with unapproved account. Email: {Email}", loginDto.Email);
            return TypedResults.Unauthorized();
        }

        var roles = await userManager.GetRolesAsync(user);
        var token = GenerateJwtToken(user, roles, configuration);

        return TypedResults.Ok(new AuthResponseDto { Token = token, EmployeeId = user.Employee!.Id });
    }

    private static string GenerateJwtToken(ApplicationUser user, IList<string> roles, IConfiguration configuration)
    {
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id),
            new(JwtRegisteredClaimNames.Email, user.Email!),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new("employeeId", user.Employee!.Id.ToString())
        };

        claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Secret"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.Now.AddDays(Convert.ToDouble(configuration["Jwt:ExpiresInDays"] ?? "1"));

        var token = new JwtSecurityToken(
            issuer: configuration["Jwt:Issuer"],
            audience: configuration["Jwt:Audience"],
            claims: claims,
            expires: expires,
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static async Task<Results<Ok, NotFound>> HandleForgotPasswordAsync(
        ForgotPasswordDto forgotPasswordDto,
        UserManager<ApplicationUser> userManager,
        IEmailService emailService,
        IConfiguration config)
    {
        var user = await userManager.FindByEmailAsync(forgotPasswordDto.Email!);

        if (user is null)
        {
            return TypedResults.Ok();
        }

        var token = await userManager.GeneratePasswordResetTokenAsync(user);
        var encodedToken = HttpUtility.UrlEncode(token);

        var resetLink = $"{config["WebAppUrl"]}/reset-password?token={encodedToken}&email={user.Email}";

        await emailService.SendPasswordResetEmailAsync(user.Email!, resetLink);

        return TypedResults.Ok();
    }

    private static async Task<Results<Ok, BadRequest<string>>> HandleResetPasswordAsync(
        ResetPasswordDto resetPasswordDto,
        UserManager<ApplicationUser> userManager)
    {
        var user = await userManager.FindByEmailAsync(resetPasswordDto.Email!);
        if (user is null)
        {
            return TypedResults.BadRequest("Invalid request.");
        }

        var decodedToken = HttpUtility.UrlDecode(resetPasswordDto.Token);

        if (decodedToken is null)
        {
            return TypedResults.BadRequest("Invalid token.");
        }

        var result = await userManager.ResetPasswordAsync(user, decodedToken, resetPasswordDto.NewPassword!);

        if (!result.Succeeded)
        {
            var errors = string.Join(", ", result.Errors.Select(e => e.Description));
            return TypedResults.BadRequest(errors);
        }

        return TypedResults.Ok();
    }
}
