﻿using Microsoft.AspNetCore.Http.HttpResults;
using ProScheduler.Api.Contracts.Person.Patient;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class PatientsApi
{
    const string GetPatientEndpointName = "GetPatient";

    public static RouteGroupBuilder MapPatientsEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/patients")
            .WithTags("Patients")
            .WithParameterValidation();

        // GET /api/patients
        group.MapGet("/", HandleGetPatientsAsync);

        // GET /api/patients/{id}
        group.MapGet("/{id:int}", HandleGetPatientByIdAsync)
            .WithName(GetPatientEndpointName);

        // POST /api/patients
        group.MapPost("/", HandlePostPatientAsync);

        // PUT /api/patients/{id}
        group.MapPut("/{id:int}", HandleUpdatePatientAsync);

        // DELETE /api/patients/{id}
        group.MapDelete("/{id:int}", HandleDeletePatientAsync);

        // GET /api/patients/{id}/report
        group.MapGet("/{id:int}/report", HandleGetPatientReportAsync)
            .Produces(StatusCodes.Status200OK, typeof(byte[]), "application/pdf");

        return group;
    }

    private static async Task<Ok<IEnumerable<PatientDto>>> HandleGetPatientsAsync(IPatientService patientService)
    {
        return TypedResults.Ok(await patientService.GetAllPatientsAsync());
    }

    private static async Task<Results<NotFound<string>, Ok<PatientDto>>> HandleGetPatientByIdAsync(int id, IPatientService patientService)
    {
        var serviceResponse = await patientService.GetPatientByIdAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<BadRequest<string>, CreatedAtRoute<PatientDto>>> HandlePostPatientAsync(CreatePatientDto createPatientDto, IPatientService patientService)
    {
        var serviceResponse = await patientService.CreatePatientAsync(createPatientDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.CreatedAtRoute(serviceResponse.Value, GetPatientEndpointName, new { id = serviceResponse.Value.Id }),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, BadRequest<string>, NoContent>> HandleUpdatePatientAsync(int id, UpdatePatientDto updatePatientDto, IPatientService patientService)
    {
        var serviceResponse = await patientService.UpdatePatientAsync(id, updatePatientDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<NoContent> HandleDeletePatientAsync(int id, IPatientService patientService)
    {
        await patientService.DeletePatientAsync(id);
        return TypedResults.NoContent();
    }

    private static async Task<Results<NotFound<string>, FileContentHttpResult>> HandleGetPatientReportAsync(int id, IPatientService patientService)
    {
        var serviceResponse = await patientService.GeneratePatientReportAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.File(serviceResponse.Value.file, "application/pdf", serviceResponse.Value.name),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }
}
