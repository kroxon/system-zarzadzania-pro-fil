﻿using Microsoft.AspNetCore.Http.HttpResults;
using ProScheduler.Api.Contracts.WorkHours;
using ProScheduler.Api.Services;

namespace ProScheduler.Api.Endpoints;

public static class WorkHoursApi
{
    private const string GetWorkHoursEndpointName = "GetWorkHours";

    public static RouteGroupBuilder MapWorkHoursEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/workhours")
            .WithTags("WorkHours")
            .WithParameterValidation()
            .RequireAuthorization("CanModifyWorkHours");

        // GET /api/workhours
        group.MapGet("/", HandleGetWorkHoursAsync);

        // GET /api/workhours/{id}
        group.MapGet("/{id:int}", HandleGetWorkHoursByIdAsync)
            .WithName(GetWorkHoursEndpointName);

        // POST /api/workhours
        group.MapPost("/", HandlePostWorkHoursAsync);

        // PUT /api/workhours/{id}
        group.MapPut("/{id:int}", HandleUpdateWorkHoursAsync);

        // DELETE /api/workhours/{id}
        group.MapDelete("/{id:int}", HandleDeleteWorkHoursAsync);

        return group;
    }

    private static async Task<Ok<IEnumerable<WorkHoursDto>>> HandleGetWorkHoursAsync(IWorkHoursService workHoursService)
    {
        return TypedResults.Ok(await workHoursService.GetAllWorkHoursAsync());
    }

    private static async Task<Results<NotFound<string>, Ok<WorkHoursDto>>> HandleGetWorkHoursByIdAsync(int id, IWorkHoursService workHoursService)
    {
        var serviceResponse = await workHoursService.GetWorkHoursByIdAsync(id);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.Ok(serviceResponse.Value),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<BadRequest<string>, CreatedAtRoute<WorkHoursDto>>> HandlePostWorkHoursAsync(CreateWorkHoursDto createWorkHoursDto, IWorkHoursService workHoursService)
    {
        var serviceResponse = await workHoursService.CreateWorkHoursAsync(createWorkHoursDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.CreatedAtRoute(serviceResponse.Value, GetWorkHoursEndpointName, new { id = serviceResponse.Value.Id }),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            { Error.Type: ErrorType.NotFound } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<Results<NotFound<string>, BadRequest<string>, NoContent>> HandleUpdateWorkHoursAsync(int id, UpdateWorkHoursDto updateWorkHoursDto, IWorkHoursService workHoursService)
    {
        var serviceResponse = await workHoursService.UpdateWorkHoursAsync(id, updateWorkHoursDto);
        return serviceResponse switch
        {
            { IsSuccess: true } => TypedResults.NoContent(),
            { Error.Type: ErrorType.NotFound } => TypedResults.NotFound(serviceResponse.Error.Description),
            { Error.Type: ErrorType.Validation } => TypedResults.BadRequest(serviceResponse.Error.Description),
            _ => throw new NotSupportedException($"The error type '{serviceResponse.Error.Type}' is not supported by this endpoint.")
        };
    }

    private static async Task<NoContent> HandleDeleteWorkHoursAsync(int id, IWorkHoursService workHoursService)
    {
        await workHoursService.DeleteWorkHoursAsync(id);
        return TypedResults.NoContent();
    }
}
