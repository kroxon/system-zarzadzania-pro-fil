﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Event;

public record UpdateEventDto
{
    [Required]
    [MaxLength(100)]
    public string? Name { get; init; }

    [Required]
    public DateTime? Start { get; init; }

    [Required]
    public DateTime? End { get; init; }

    [Required]
    public HashSet<int>? ParticipantIds { get; init; }

    public int? RoomId { get; init; }

    public string? Info { get; init; }

    public string? Guest { get; init; }
}
