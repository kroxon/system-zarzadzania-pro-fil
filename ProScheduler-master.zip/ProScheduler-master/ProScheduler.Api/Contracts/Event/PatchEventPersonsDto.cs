﻿namespace ProScheduler.Api.Contracts.Event;

public record PatchEventPersonsDto
{
    public HashSet<int>? AddPersonsIds { get; init; }
    public HashSet<int>? RemovePersonsIds { get; init; }
}
