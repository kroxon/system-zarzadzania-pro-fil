﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Event;

public record EventDto
{
    [Required]
    public int? Id { get; init; }

    [Required]
    [MaxLength(100)]
    public string? Name { get; init; }

    [Required]
    public DateTime? Start { get; init; }

    [Required]
    public DateTime? End { get; init; }

    [Required]
    public List<int>? ParticipantIds { get; init; }

    [Required]
    public int? StatusId { get; init; }

    public int? RoomId { get; init; }

    public string? Info { get; set; }

    public string? Guest { get; set; }
}
