﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Occupation;

public record UpdateOccupationDto
{
    [Required]
    [StringLength(50)]
    public string? Name { get; init; }
}
