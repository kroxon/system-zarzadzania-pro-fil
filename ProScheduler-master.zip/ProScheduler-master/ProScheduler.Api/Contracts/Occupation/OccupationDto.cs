﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Occupation;

public record OccupationDto
{
    [Required]
    public int? Id { get; init; }

    [Required]
    [StringLength(50)]
    public string? Name { get; init; }
}
