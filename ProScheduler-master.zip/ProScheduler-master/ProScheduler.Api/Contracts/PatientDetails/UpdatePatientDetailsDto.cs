﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.PatientDetails;

public record UpdatePatientDetailsDto
{
    [Required]
    public DateOnly? BirthDate { get; init; }
    public string? Info { get; init; }
}
