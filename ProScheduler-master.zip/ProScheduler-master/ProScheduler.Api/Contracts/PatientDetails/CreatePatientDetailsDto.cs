﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.PatientDetails;

public record CreatePatientDetailsDto
{
    [Required]
    public int? PersonId { get; init; }

    [Required]
    public DateOnly? BirthDate { get; init; }

    public string? Info { get; init; }
}
