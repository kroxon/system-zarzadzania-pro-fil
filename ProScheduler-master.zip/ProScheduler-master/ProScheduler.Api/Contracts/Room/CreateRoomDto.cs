﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Room;

public record CreateRoomDto
{
    [Required]
    public string? Name { get; init; }

    [Required]
    public string? HexColor { get; init; }
}
