﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Employee;

public record CreateEmployeeDto : CreatePersonDto
{
    [Required]
    [EmailAddress]
    [MaxLength(100)]
    public string? Email { get; init; }

    [Required]
    public int? OccupationId { get; init; }
}
