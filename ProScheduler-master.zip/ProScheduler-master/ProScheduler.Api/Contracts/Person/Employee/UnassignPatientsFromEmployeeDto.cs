﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Employee;

public record UnassignPatientsFromEmployeeDto
{
    [Required]
    public List<int>? PatientIds { get; init; }
}
