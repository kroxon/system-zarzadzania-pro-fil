﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Employee;

public record UpdateEmployeeDto : UpdatePersonDto
{
    [Required]
    [EmailAddress]
    [MaxLength(100)]
    public string? Email { get; init; }

    [Required]
    public int? OccupationId { get; init; }
}
