﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Employee;

public record AssignPatientsToEmployeeDto
{
    [Required]
    public List<int>? PatientIds { get; init; }
}
