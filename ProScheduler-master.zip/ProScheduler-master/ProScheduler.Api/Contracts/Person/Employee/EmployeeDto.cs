﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Employee;

public record EmployeeDto : PersonDto
{
    [Required]
    [EmailAddress]
    [MaxLength(100)]
    public string? Email { get; init; }

    [Required]
    public int? OccupationId { get; init; }

    [Required]
    public string? OccupationName { get; init; }

    [Required]
    public ICollection<string>? Roles { get; init; }

    [Required]
    public ICollection<int>? AssignedPatientsIds { get; init; }
}
