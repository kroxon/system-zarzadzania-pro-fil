﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Patient;

public record CreatePatientDto : CreatePersonDto
{
    [Required]
    public DateOnly? BirthDate { get; init; }

    [Required]
    public bool IsActive { get; init; }
}
