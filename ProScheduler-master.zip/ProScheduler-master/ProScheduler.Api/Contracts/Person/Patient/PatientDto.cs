﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Patient;

public record PatientDto : PersonDto
{
    [Required]
    public DateOnly? BirthDate { get; init; }

    [Required]
    public ICollection<int>? AssignedEmployeesIds { get; init; }

    [Required]
    public bool IsActive { get; init; }
}
