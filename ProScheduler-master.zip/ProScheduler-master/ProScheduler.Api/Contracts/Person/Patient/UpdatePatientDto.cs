﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person.Patient;

public record UpdatePatientDto : UpdatePersonDto
{
    [Required]
    public DateOnly? BirthDate { get; init; }

    [Required]
    public bool IsActive { get; init; }
}
