﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Person;

public abstract record PersonDto
{
    [Required]
    public int? Id { get; init; }

    [Required]
    [MaxLength(50)]
    public string? Name { get; init; }

    [Required]
    [MaxLength(50)]
    public string? Surname { get; init; }

    [MaxLength(2000)]
    public string? Info { get; init; }
}
