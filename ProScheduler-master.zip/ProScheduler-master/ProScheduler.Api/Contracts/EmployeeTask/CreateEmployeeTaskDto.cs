﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.EmployeeTask;

public record CreateEmployeeTaskDto
{
    [Required]
    public string? Name { get; init; }

    [Required]
    public bool? IsCompleted { get; init; }

    [Required]
    public DateOnly? DueDate { get; init; }

    [Required]
    public HashSet<int>? AssignedEmployeesIds { get; init; }
}
