﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.EmployeeTask;

public record EmployeeTaskDto
{
    [Required]
    public int Id { get; init; }

    [Required]
    public string? Name { get; init; }

    [Required]
    public bool? IsCompleted { get; init; }

    [Required]
    public DateOnly? DueDate { get; init; }

    [Required]
    public List<int>? AssignedEmployeesIds { get; init; }
}
