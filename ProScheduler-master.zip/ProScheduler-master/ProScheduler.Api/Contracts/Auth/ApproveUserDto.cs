﻿using ProScheduler.Api.Models;
using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record ApproveUserDto
{
    [Required]
    public Role? Role { get; init; }
}
