﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record ResetPasswordDto
{
    [Required]
    [EmailAddress]
    public string? Email { get; init; }

    [Required]
    public string? Token { get; init; }

    [Required]
    public string? NewPassword { get; init; }
}
