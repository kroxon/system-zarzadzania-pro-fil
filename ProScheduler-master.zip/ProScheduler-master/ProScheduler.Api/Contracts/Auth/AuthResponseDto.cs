﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record AuthResponseDto
{
    [Required]
    public string? Token { get; init; }

    [Required]
    public int? EmployeeId { get; init; }
}