﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record LoginDto
{
    [Required]
    [EmailAddress]
    [MaxLength(100)]
    public string? Email { get; init; }

    [Required]
    public string? Password { get; init; }
}