﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record ForgotPasswordDto
{
    [Required]
    [EmailAddress]
    public string? Email { get; init; }
}
