﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Auth;

public record RegisterDto
{
    [Required]
    [MaxLength(50)]
    public string? Name { get; init; }

    [Required]
    [MaxLength(50)]
    public string? Surname { get; init; }

    [Required]
    [EmailAddress]
    [MaxLength(100)]
    public string? Email { get; init; }

    [Required]
    public string? Password { get; init; }

    [Required]
    public int? OccupationId { get; init; }
}
