﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.WorkHours;

public record UpdateWorkHoursDto
{
    [Required]
    public required DateTime Start { get; set; }

    [Required]
    public required DateTime End { get; set; }

    [Required]
    public required int EmployeeId { get; set; }
}
