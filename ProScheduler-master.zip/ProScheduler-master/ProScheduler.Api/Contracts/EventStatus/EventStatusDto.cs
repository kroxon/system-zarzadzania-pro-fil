﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.EventStatus;

public record EventStatusDto
{
    [Required]
    public int? Id { get; init; }

    [Required]
    public string? Name { get; init; }
}
