﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Event;

public record MainPanelStatisticDto
{
    [Required]
    public int? Today { get; init; }
    [Required]
    public int? Tomorrow { get; init; }
    [Required]
    public int? ThisWeek { get; init; }
    [Required]
    public int? ThisMonth { get; init; }
    [Required]
    public int? ActivePatients { get; init; }
}
