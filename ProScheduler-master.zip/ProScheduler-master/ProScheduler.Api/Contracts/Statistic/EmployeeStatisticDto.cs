﻿using System.ComponentModel.DataAnnotations;

namespace ProScheduler.Api.Contracts.Statistic;

public record EmployeeStatisticDto
{
    [Required]
    public int? EmployeeId { get; init; }

    [Required]
    public int? TotalEvents { get; init; }

    [Required]
    public int? CompletedEvents { get; init; }

    [Required]
    public int? CancelledEvents { get; init; }

    [Required]
    public int? AbsentPatients { get; init; }
}
