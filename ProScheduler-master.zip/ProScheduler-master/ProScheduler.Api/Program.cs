using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ProScheduler.Api.Data;
using ProScheduler.Api.Endpoints;
using ProScheduler.Api.Middleware;
using ProScheduler.Api.Models;
using ProScheduler.Api.Services;
using ProScheduler.Api.Services.ReportServices;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
{
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});
builder.Services.Configure<Microsoft.AspNetCore.Mvc.JsonOptions>(options =>
{
    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
});
builder.Services.AddSwaggerGen(options =>
{
    options.CustomSchemaIds(type => type.Name.EndsWith("Dto")
        ? type.Name.Replace("Dto", string.Empty)
        : type.Name);

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter a valid token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new List<string>()
        }
    });

    options.OperationFilter<Add401ResponseOperationFilter>();
});

builder.Services.AddCors(options =>
    options.AddDefaultPolicy(policy =>
        policy.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod()));

builder.Services.AddScoped<IEventService, EventService>();
builder.Services.AddScoped<IWorkHoursService, WorkHoursService>();
builder.Services.AddScoped<IEmployeeService, EmployeeService>();
builder.Services.AddScoped<IPatientService, PatientService>();
builder.Services.AddScoped<AvailabilityService>();
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddHostedService<EventStatusUpdaterService>();
builder.Services.AddTransient<PatientReportService>();
builder.Services.AddTransient<EmployeeReportService>();
builder.Services.AddScoped<EmployeeTaskService>();
builder.Services.AddScoped<StatisticsService>();

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    // TODO: change in production
    options.Password.RequireDigit = false;
    options.Password.RequiredLength = 4;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;

    options.User.RequireUniqueEmail = true;
})
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddJwtBearer(options => options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"]!))
    });

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("AdminOnly", policy => policy.RequireRole(Role.Admin.ToString()))
    .AddPolicy("CanScheduleForAll", policy => policy.RequireRole(Role.Admin.ToString(), Role.FirstContact.ToString()))
    .AddPolicy("CanModifyWorkHours", policy => policy.RequireRole(Role.Admin.ToString()))
    .SetFallbackPolicy(new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
                       ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(connectionString));

var app = builder.Build();

// Configure the HTTP request pipeline.

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapAuthEndpoints();
app.MapAdminEndpoints();
app.MapOccupationsEndpoints();
app.MapEventsEndpoints();
app.MapEventStatusesEndpoints();
app.MapRoomsEndpoints();
app.MapEmployeesEndpoints();
app.MapPatientsEndpoints();
app.MapWorkHoursEndpoints();
app.MapEmployeeTasksEndpoints();
app.MapStatisticsEndpoints();

await app.DeleteAndMigrateDatabaseAsync();
await app.SeedDatabaseAsync();

app.Run();
