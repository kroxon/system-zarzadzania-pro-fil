﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Person> Persons { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Patient> Patients { get; set; }
    public DbSet<Event> Events { get; set; }
    public DbSet<Room> Rooms { get; set; }
    public DbSet<EventStatus> EventStatuses { get; set; }
    public DbSet<WorkHours> WorkHours { get; set; }
    public DbSet<Occupation> Occupations { get; set; }
    public DbSet<EmployeeTask> EmployeeTasks { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<EventStatus>().HasData(
            new EventStatus { Id = 1, Name = "Zaplanowane" },
            new EventStatus { Id = 2, Name = "W Trakcie" },
            new EventStatus { Id = 3, Name = "Ukończone" },
            new EventStatus { Id = 4, Name = "Nieobecny" },
            new EventStatus { Id = 5, Name = "Anulowane" }
        );

        modelBuilder.Entity<Occupation>().HasData(
            new Occupation { Id = 1, Name = "Inna" },
            new Occupation { Id = 2, Name = "Terapeuta" },
            new Occupation { Id = 3, Name = "Prawnik" },
            new Occupation { Id = 4, Name = "Psycholog" }
        );

        modelBuilder.Entity<Event>()
            .HasOne(e => e.Room)
            .WithMany(r => r.Events)
            .HasForeignKey(e => e.RoomId)
            .OnDelete(DeleteBehavior.SetNull);

        modelBuilder.Entity<ApplicationUser>()
            .HasMany(u => u.UserRoles)
            .WithOne()
            .HasForeignKey(ur => ur.UserId)
            .IsRequired();
    }
}
