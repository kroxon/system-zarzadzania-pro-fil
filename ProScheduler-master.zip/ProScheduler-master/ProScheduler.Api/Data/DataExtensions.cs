﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Data;

public static class DataExtensions
{
    public static async Task DeleteAndMigrateDatabaseAsync(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        await dbContext.Database.EnsureDeletedAsync();
        await dbContext.Database.MigrateAsync();
    }

    public static async Task SeedDatabaseAsync(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        List<Task> seedingTasks = new()
        {
            SeedRolesAsync(roleManager),
            SeedRoomsAsync(dbContext),
            SeedPatientsAsync(dbContext)
        };
        await Task.WhenAll(seedingTasks);
        await SeedEmployeesAsync(dbContext, userManager);
        seedingTasks = new()
        {
            SeedEventsAsync(dbContext),
            SeedWorkHoursAsync(dbContext),
        };
        await Task.WhenAll(seedingTasks);
        await SeedEventPersonsAsync(dbContext);
    }

    private static async Task SeedRolesAsync(RoleManager<IdentityRole> roleManager)
    {
        foreach (var roleName in Enum.GetValues<Role>())
        {
            if (!await roleManager.RoleExistsAsync(roleName.ToString()))
            {
                await roleManager.CreateAsync(new IdentityRole(roleName.ToString()));
            }
        }
    }

    private static async Task SeedEmployeesAsync(ApplicationDbContext dbContext, UserManager<ApplicationUser> userManager)
    {
        if (await dbContext.Employees.AnyAsync() || await userManager.Users.AnyAsync())
        {
            return;
        }

        await CreateUserWithEmployeeAsync(
            dbContext,
            userManager,
            name: "Bolec",
            surname: "Milowicz",
            email: "bolec@proscheduler.com",
            password: "admin",
            role: Role.Admin,
            occupationId: 3
        );

        await CreateUserWithEmployeeAsync(
            dbContext,
            userManager,
            name: "Fred",
            surname: "Pazura",
            email: "fred@proscheduler.com",
            password: "test",
            role: Role.FirstContact,
            occupationId: 2,
            info: "Elegant"
        );

        await CreateUserWithEmployeeAsync(
            dbContext,
            userManager,
            name: "Grucha",
            surname: "Zbrojewicz",
            email: "grucha@proscheduler.com",
            password: "test",
            role: Role.Employee,
            occupationId: 2
        );
    }

    private static async Task CreateUserWithEmployeeAsync(ApplicationDbContext db, UserManager<ApplicationUser> userManager, string name, string surname, string email, string password, Role role, int occupationId, string? info = null)
    {
        var user = new ApplicationUser
        {
            Name = name,
            Surname = surname,
            Email = email,
            UserName = email,
            EmailConfirmed = true,
            OccupationId = occupationId
        };

        var result = await userManager.CreateAsync(user, password);
        if (!result.Succeeded)
        {
            throw new Exception($"Failed to create user {email}. Errors: {string.Join(", ", result.Errors.Select(e => e.Description))}");
        }

        var employee = new Employee
        {
            Name = name,
            Surname = surname,
            Info = info,
            ApplicationUserId = user.Id
        };

        db.Employees.Add(employee);
        await db.SaveChangesAsync();
        await userManager.AddToRoleAsync(user, role.ToString());
    }

    private static async Task SeedPatientsAsync(ApplicationDbContext dbContext)
    {
        if (!await dbContext.Patients.AnyAsync())
        {
            dbContext.Patients.AddRange(
                new Patient { Name = "Kuba", Surname = "Stuhr", BirthDate = new DateOnly(1990, 1, 1), 
                    Info = "utalentowany skrzypek, który przez przypadek wplątany zostaje w aferę" +
                    " z gangsterami. Wraz ze swoim nieśmiałym przyjacielem Oskarem, odwiedza agencję " +
                    "towarzyską, a nie mając pieniędzy na zapłatę, zostaje świadkiem strzelaniny," +
                    " w której ginie walizka z pieniędzmi. Teraz gangsterzy, którzy podejrzewają," +
                    " że to on je zabrał, depczą mu po piętach, a jego życie jest w śmiertelnym niebezpieczeństwie. " },
                new Patient { Name = "Laska", Surname = "Bajer", BirthDate = new DateOnly(1992, 2, 2), Info = "Cukrzyca." },
                new Patient { Name = "Lili", Surname = "Mucha", BirthDate = new DateOnly(1995, 3, 3), IsActive = false }
            );
            await dbContext.SaveChangesAsync();
        }
    }

    private static async Task SeedRoomsAsync(ApplicationDbContext dbContext)
    {
        if (!await dbContext.Rooms.AnyAsync())
        {
            dbContext.Rooms.AddRange(
                new Room { Name = "Gabinet A", HexColor = "#FF0000" },
                new Room { Name = "Gabinet B", HexColor = "#00FF00" },
                new Room { Name = "Sala Terapii", HexColor = "#0000FF" },
                new Room { Name = "Sala Konsultacyjna", HexColor = "#FFFF00" },
                new Room { Name = "Sala Grupowa", HexColor = "#FF00FF" }
            );
            await dbContext.SaveChangesAsync();
        }
    }

    private static async Task SeedEventsAsync(ApplicationDbContext dbContext)
    {
        var room1 = await dbContext.Rooms.FirstOrDefaultAsync(r => r.Name == "Gabinet A") 
            ?? throw new Exception("Seeding Events failed due to missing Rooms.");

        if (!await dbContext.Events.AnyAsync())
        {
            dbContext.Events.AddRange(
                new Event { Name = "Rozmowa w samochodzie Freda", Start = new DateTime(2025, 09, 1, 10, 00, 00), End = new DateTime(2025, 09, 1, 11, 00, 00), StatusId = 1, RoomId = room1.Id },
                new Event { Name = "Spotkanie w mieszkaniu Oskara", Start = new DateTime(2025, 09, 1, 10, 00, 00), End = new DateTime(2025, 09, 1, 12, 00, 00), StatusId = 1, Guest = "Oskar", 
                        Info = """
                            Kuba: Nie, no nie ma pośpiechu... Może sobie najpierw pogadamy?
                            Cycofon: A niby kurde o czym?
                            K: No nie wiem, o twojej pracy, albo...
                            C: Robota jak każda, generalnie kiedy facet jest na mnie to myślę o czymś innym nieee? na przykład kurde o księżnej Dianie, o nowej pralce, o testach do „Koła fortuny”, a jak klient jest wyjątkowo brzydki to zamykam oczy i wyobrażam sobie, że bzykam się z di Caprio...
                        """
                },

                new Event { Name = "PlannedToInProgress", Start = new DateTime(2025, 09, 9, 20, 35, 00), End = new DateTime(2025, 09, 9, 20, 40, 00), StatusId = 1},
                new Event { Name = "InProgressToCompleted", Start = new DateTime(2025, 09, 9, 20, 30, 00), End = new DateTime(2025, 09, 9, 20, 34, 00), StatusId = 2 },
                new Event { Name = "BezZmian", Start = new DateTime(2025, 09, 9, 20, 30, 00), End = new DateTime(2025, 09, 9, 20, 41, 00), StatusId = 2 },

                new Event { Name = "Report test", Start = new DateTime(2025, 09, 9, 20, 30, 00), End = new DateTime(2025, 09, 9, 20, 41, 00), StatusId = 2, Info = "test" }
            );
            await dbContext.SaveChangesAsync();
        }
    }

    private static async Task SeedEventPersonsAsync(ApplicationDbContext dbContext)
    {
        var event1 = await dbContext.Events.Include(e => e.Persons).FirstOrDefaultAsync(e => e.Name == "Rozmowa w samochodzie Freda");
        var event2 = await dbContext.Events.Include(e => e.Persons).FirstOrDefaultAsync(e => e.Name == "Spotkanie w mieszkaniu Oskara");
        var eventReportTest = await dbContext.Events.Include(e => e.Persons).FirstOrDefaultAsync(e => e.Name == "Report test");
        var Fred = await dbContext.Employees.FirstOrDefaultAsync(p => p.Name == "Fred");
        var Grucha = await dbContext.Employees.FirstOrDefaultAsync(p => p.Name == "Grucha");
        var Kuba = await dbContext.Patients.FirstOrDefaultAsync(p => p.Name == "Kuba");
        var Laska = await dbContext.Patients.FirstOrDefaultAsync(p => p.Name == "Laska");
        var Lili = await dbContext.Patients.FirstOrDefaultAsync(p => p.Name == "Lili");

        if (event1 is null || event2 is null || eventReportTest is null || Fred is null || Grucha is null || Kuba is null || Laska is null || Lili is null)
        {
            throw new Exception("Seeding EventPersons failed due to missing data.");
        }

        event1.Persons.Add(Fred);
        event1.Persons.Add(Grucha);

        event2.Persons.Add(Kuba);
        event2.Persons.Add(Laska);
        event2.Persons.Add(Lili);

        eventReportTest.Persons.Add(Fred);
        eventReportTest.Persons.Add(Kuba);

        await dbContext.SaveChangesAsync();
    }

    private static async Task SeedWorkHoursAsync(ApplicationDbContext dbContext)
    {
        var Fred = await dbContext.Employees.FirstOrDefaultAsync(p => p.Name == "Fred");
        var Grucha = await dbContext.Employees.FirstOrDefaultAsync(p => p.Name == "Grucha");
        var Bolec = await dbContext.Employees.FirstOrDefaultAsync(p => p.Name == "Bolec");
        if (Fred is null || Grucha is null || Bolec is null)
        {
            throw new Exception("Seeding WorkHours failed due to missing Employees.");
        }

        if (!await dbContext.WorkHours.AnyAsync())
        {
            dbContext.WorkHours.AddRange(
                new WorkHours { EmployeeId = Fred.Id, Start = new DateTime(2025, 09, 1, 8, 00, 00), End = new DateTime(2025, 09, 1, 16, 00, 00) },
                new WorkHours { EmployeeId = Grucha.Id, Start = new DateTime(2025, 09, 1, 9, 00, 00), End = new DateTime(2025, 09, 1, 17, 00, 00) },
                new WorkHours { EmployeeId = Bolec.Id, Start = new DateTime(2025, 09, 1, 10, 00, 00), End = new DateTime(2025, 09, 1, 15, 00, 00) }
            );
            await dbContext.SaveChangesAsync();
        }
    }
}
