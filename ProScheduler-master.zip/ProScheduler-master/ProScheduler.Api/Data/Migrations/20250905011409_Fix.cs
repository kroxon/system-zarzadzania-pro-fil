﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProScheduler.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class Fix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkHours_Persons_EmployeeId",
                table: "WorkHours");

            migrationBuilder.DropForeignKey(
                name: "FK_WorkHours_Persons_PersonId",
                table: "WorkHours");

            migrationBuilder.DropIndex(
                name: "IX_WorkHours_PersonId",
                table: "WorkHours");

            migrationBuilder.DropColumn(
                name: "PersonId",
                table: "WorkHours");

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "WorkHours",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_WorkHours_Persons_EmployeeId",
                table: "WorkHours",
                column: "EmployeeId",
                principalTable: "Persons",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkHours_Persons_EmployeeId",
                table: "WorkHours");

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "WorkHours",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AddColumn<int>(
                name: "PersonId",
                table: "WorkHours",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_WorkHours_PersonId",
                table: "WorkHours",
                column: "PersonId");

            migrationBuilder.AddForeignKey(
                name: "FK_WorkHours_Persons_EmployeeId",
                table: "WorkHours",
                column: "EmployeeId",
                principalTable: "Persons",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_WorkHours_Persons_PersonId",
                table: "WorkHours",
                column: "PersonId",
                principalTable: "Persons",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
