﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProScheduler.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class ChangeRoleNamesToPl : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Inna");

            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "Terapeuta");

            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Prawnik");

            migrationBuilder.InsertData(
                table: "Occupations",
                columns: new[] { "Id", "Name" },
                values: new object[] { 4, "Psycholog" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Other");

            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "The Mob");

            migrationBuilder.UpdateData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Brothel Man");
        }
    }
}
