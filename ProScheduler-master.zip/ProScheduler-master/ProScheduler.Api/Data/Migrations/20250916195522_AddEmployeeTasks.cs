﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProScheduler.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddEmployeeTasks : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeeTasks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    IsCompleted = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeTasks", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeEmployeeTask",
                columns: table => new
                {
                    AssignedEmployeesId = table.Column<int>(type: "INTEGER", nullable: false),
                    AssignedTasksId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeEmployeeTask", x => new { x.AssignedEmployeesId, x.AssignedTasksId });
                    table.ForeignKey(
                        name: "FK_EmployeeEmployeeTask_EmployeeTasks_AssignedTasksId",
                        column: x => x.AssignedTasksId,
                        principalTable: "EmployeeTasks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmployeeEmployeeTask_Persons_AssignedEmployeesId",
                        column: x => x.AssignedEmployeesId,
                        principalTable: "Persons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeEmployeeTask_AssignedTasksId",
                table: "EmployeeEmployeeTask",
                column: "AssignedTasksId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeEmployeeTask");

            migrationBuilder.DropTable(
                name: "EmployeeTasks");
        }
    }
}
