﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProScheduler.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddEmployeePatientTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeePatient",
                columns: table => new
                {
                    AssignedEmployeesId = table.Column<int>(type: "INTEGER", nullable: false),
                    AssignedPatientsId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeePatient", x => new { x.AssignedEmployeesId, x.AssignedPatientsId });
                    table.ForeignKey(
                        name: "FK_EmployeePatient_Persons_AssignedEmployeesId",
                        column: x => x.AssignedEmployeesId,
                        principalTable: "Persons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmployeePatient_Persons_AssignedPatientsId",
                        column: x => x.AssignedPatientsId,
                        principalTable: "Persons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EmployeePatient_AssignedPatientsId",
                table: "EmployeePatient",
                column: "AssignedPatientsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeePatient");
        }
    }
}
