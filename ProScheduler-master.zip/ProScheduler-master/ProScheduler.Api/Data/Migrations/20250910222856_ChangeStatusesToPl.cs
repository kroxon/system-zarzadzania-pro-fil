﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProScheduler.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class ChangeStatusesToPl : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Zaplanowane");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "W Trakcie");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Ukończone");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Nieobecny");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Anulowane");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Planned");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "In Progress");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 3,
                column: "Name",
                value: "Completed");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 4,
                column: "Name",
                value: "Absent");

            migrationBuilder.UpdateData(
                table: "EventStatuses",
                keyColumn: "Id",
                keyValue: 5,
                column: "Name",
                value: "Cancelled");
        }
    }
}
