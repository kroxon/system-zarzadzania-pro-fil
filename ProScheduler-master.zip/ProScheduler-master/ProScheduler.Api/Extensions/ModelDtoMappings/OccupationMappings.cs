﻿using ProScheduler.Api.Contracts.Occupation;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class OccupationMappings
{
    public static OccupationDto ToDto(this Occupation occupation)
    {
        return new OccupationDto
        {
            Id = occupation.Id,
            Name = occupation.Name
        };
    }

    public static Occupation ToEntity(this CreateOccupationDto occupationDto)
    {
        return new Occupation
        {
            Name = occupationDto.Name!
        };
    }

    public static Occupation ToEntity(this UpdateOccupationDto updateOccupationDto, int id)
    {
        return new Occupation
        {
            Id = id,
            Name = updateOccupationDto.Name!
        };
    }
}
