﻿using ProScheduler.Api.Contracts.Room;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class RoomMappings
{
    public static RoomDto ToDto(this Room room)
    {
        return new RoomDto
        {
            Id = room.Id,
            Name = room.Name,
            HexColor = room.HexColor
        };
    }

    public static Room ToEntity(this CreateRoomDto roomDto)
    {
        return new Room
        {
            Name = roomDto.Name!,
            HexColor = roomDto.HexColor!
        };
    }

    public static Room ToEntity(this UpdateRoomDto updateRoomDto, int id)
    {
        return new Room
        {
            Id = id,
            Name = updateRoomDto.Name!,
            HexColor = updateRoomDto.HexColor!
        };
    }
}
