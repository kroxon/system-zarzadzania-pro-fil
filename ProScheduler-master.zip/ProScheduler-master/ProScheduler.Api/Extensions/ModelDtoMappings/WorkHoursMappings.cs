﻿using ProScheduler.Api.Contracts.WorkHours;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class WorkHoursMappings
{
    public static WorkHoursDto ToDto(this WorkHours workHours)
    {
        return new WorkHoursDto
        {
            Id = workHours.Id,
            Start = workHours.Start,
            End = workHours.End,
            EmployeeId = workHours.EmployeeId
        };
    }

    public static WorkHours ToEntity(this CreateWorkHoursDto createWorkHoursDto)
    {
        return new WorkHours
        {
            Start = createWorkHoursDto.Start,
            End = createWorkHoursDto.End,
            EmployeeId = createWorkHoursDto.EmployeeId
        };
    }

    public static WorkHours ToEntity(this UpdateWorkHoursDto updateWorkHoursDto, int workHoursId)
    {
        return new WorkHours
        {
            Id = workHoursId,
            Start = updateWorkHoursDto.Start,
            End = updateWorkHoursDto.End,
            EmployeeId = updateWorkHoursDto.EmployeeId
        };
    }
}
