﻿using ProScheduler.Api.Contracts.Person.Patient;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class PatientMappings
{
    public static PatientDto ToDto(this Patient patient)
    {
        return new PatientDto
        {
            Id = patient.Id,
            Name = patient.Name,
            Surname = patient.Surname,
            BirthDate = patient.BirthDate,
            Info = patient.Info,
            AssignedEmployeesIds = patient.AssignedEmployees.Select(e => e.Id).ToList(),
            IsActive = patient.IsActive
        };
    }
    public static Patient ToEntity(this CreatePatientDto createPatientDto)
    {
        return new Patient
        {
            Name = createPatientDto.Name!,
            Surname = createPatientDto.Surname!,
            BirthDate = createPatientDto.BirthDate!.Value,
            Info = createPatientDto.Info,
            IsActive = createPatientDto.IsActive
        };
    }
    public static Patient ToEntity(this UpdatePatientDto updatePatientDto, int patientId)
    {
        return new Patient
        {
            Id = patientId,
            Name = updatePatientDto.Name!,
            Surname = updatePatientDto.Surname!,
            BirthDate = updatePatientDto.BirthDate!.Value,
            Info = updatePatientDto.Info,
            IsActive = updatePatientDto.IsActive
        };
    }
}
