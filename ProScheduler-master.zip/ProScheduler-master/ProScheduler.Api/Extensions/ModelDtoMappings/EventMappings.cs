﻿using ProScheduler.Api.Contracts.Event;
using ProScheduler.Api.Contracts.EventStatus;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class EventMappings
{
    public static EventDto ToDto(this Event @event)
    {
        return new EventDto
        {
            Id = @event.Id,
            Name = @event.Name,
            Start = @event.Start,
            End = @event.End,
            ParticipantIds = @event.Persons.Select(person => person.Id).ToList(),
            StatusId = @event.StatusId,
            RoomId = @event.RoomId,
            Info = @event.Info,
            Guest = @event.Guest
        };
    }

    public static Event ToEntity(this CreateEventDto eventDto)
    {
        return new Event
        {
            Name = eventDto.Name!,
            Start = eventDto.Start!.Value,
            End = eventDto.End!.Value,
            StatusId = StatusConstants.Planned,
            RoomId = eventDto.RoomId,
            Info = eventDto.Info,
            Status = default!,
            Guest = eventDto.Guest
        };
    }

    public static Event ToEntity(this UpdateEventDto updateEventDto, int id)
    {
        return new Event
        {
            Id = id,
            Name = updateEventDto.Name!,
            Start = updateEventDto.Start!.Value,
            End = updateEventDto.End!.Value,
            StatusId = StatusConstants.Planned,
            RoomId = updateEventDto.RoomId,
            Info = updateEventDto.Info,
            Status = default!,
            Guest = updateEventDto.Guest
        };
    }

    public static EventStatusDto ToDto(this EventStatus eventStatus)
    {
        return new EventStatusDto
        {
            Id = eventStatus.Id,
            Name = eventStatus.Name
        };
    }
}
