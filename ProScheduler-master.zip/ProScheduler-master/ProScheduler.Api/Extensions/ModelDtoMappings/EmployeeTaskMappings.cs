﻿using ProScheduler.Api.Contracts.EmployeeTask;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class EmployeeTaskMappings
{
    public static EmployeeTaskDto ToDto(this EmployeeTask employeeTask)
    {
        return new EmployeeTaskDto
        {
            Id = employeeTask.Id,
            Name = employeeTask.Name,
            IsCompleted = employeeTask.IsCompleted,
            AssignedEmployeesIds = employeeTask.AssignedEmployees.Select(e => e.Id).ToList(),
            DueDate = employeeTask.DueDate,
        };
    }

    public static EmployeeTask ToEntity(this CreateEmployeeTaskDto createEmployeeTask)
    {
        return new EmployeeTask
        {
            Name = createEmployeeTask.Name!,
            IsCompleted = createEmployeeTask.IsCompleted!.Value,
            DueDate = createEmployeeTask.DueDate!.Value,
        };
    }

    public static EmployeeTask ToEntity(this UpdateEmployeeTaskDto updateEmployeeTask, int employeeTaskId)
    {
        return new EmployeeTask
        {
            Id = employeeTaskId,
            Name = updateEmployeeTask.Name!,
            IsCompleted = updateEmployeeTask.IsCompleted!.Value,
            DueDate = updateEmployeeTask.DueDate!.Value,
        };
    }
}
