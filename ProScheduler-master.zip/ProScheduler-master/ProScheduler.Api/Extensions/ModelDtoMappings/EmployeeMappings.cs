﻿using ProScheduler.Api.Contracts.Person.Employee;
using ProScheduler.Api.Models;

namespace ProScheduler.Api.Extensions.ModelDtoMappings;

public static class EmployeeMappings
{
    public static EmployeeDto ToDto(this Employee employee, ApplicationUser? applicationUser, Occupation? occupation, ICollection<string>? roles, ICollection<int>? assignedPatientsIds)
    {
        return new EmployeeDto
        {
            Id = employee.Id,
            Name = employee.Name,
            Surname = employee.Surname,
            Email = applicationUser?.Email,
            OccupationId = applicationUser?.OccupationId,
            OccupationName = occupation?.Name,
            Info = employee.Info,
            Roles = roles,
            AssignedPatientsIds = assignedPatientsIds
        };
    }

    public static Employee ToEntity(this UpdateEmployeeDto updateEmployeeDto, int employeeId, string applicationUserId)
    {
        return new Employee
        {
            Id = employeeId,
            Name = updateEmployeeDto.Name!,
            Surname = updateEmployeeDto.Surname!,
            Info = updateEmployeeDto.Info,
            ApplicationUserId = applicationUserId
        };
    }
}
